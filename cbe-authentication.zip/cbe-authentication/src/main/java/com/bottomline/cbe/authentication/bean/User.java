package com.bottomline.cbe.authentication.bean;

import java.io.Serializable;

public class User implements Serializable {
	private static final long serialVersionUID = 1L;

	private String sessionId;
	private boolean mustChangePassword = false; // must the password be changed?
	private long pswdExpirationDays = 0; // # days until password expires
	private boolean showPswdExpirationWarning = false; // should a pswd expiration warning be shown?
	private boolean showLicenseAgreement = false; // should a license agreement be shown?
	private boolean firstLogin = false; // is this the users first login
	private boolean secAnswersNeeded = false;
	private String lastloginTime;
    private String userName;
    
	
	public String getLastloginTime() {
		return lastloginTime;
	}
	public void setLastloginTime(String lastloginTime) {
		this.lastloginTime = lastloginTime;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getSessionId() {
		return sessionId;
	}
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	public boolean isMustChangePassword() {
		return mustChangePassword;
	}
	public void setMustChangePassword(boolean mustChangePassword) {
		this.mustChangePassword = mustChangePassword;
	}
	public long getPswdExpirationDays() {
		return pswdExpirationDays;
	}
	public void setPswdExpirationDays(long pswdExpirationDays) {
		this.pswdExpirationDays = pswdExpirationDays;
	}
	public boolean isShowPswdExpirationWarning() {
		return showPswdExpirationWarning;
	}
	public void setShowPswdExpirationWarning(boolean showPswdExpirationWarning) {
		this.showPswdExpirationWarning = showPswdExpirationWarning;
	}
	public boolean isShowLicenseAgreement() {
		return showLicenseAgreement;
	}
	public void setShowLicenseAgreement(boolean showLicenseAgreement) {
		this.showLicenseAgreement = showLicenseAgreement;
	}
	public boolean isFirstLogin() {
		return firstLogin;
	}
	public void setFirstLogin(boolean firstLogin) {
		this.firstLogin = firstLogin;
	}
	public boolean isSecAnswersNeeded() {
		return secAnswersNeeded;
	}
	public void setSecAnswersNeeded(boolean secAnswersNeeded) {
		this.secAnswersNeeded = secAnswersNeeded;
	}
	
	
	
}
