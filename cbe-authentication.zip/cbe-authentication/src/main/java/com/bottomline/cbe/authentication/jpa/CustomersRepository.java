package com.bottomline.cbe.authentication.jpa;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bottomline.cbe.authentication.jpa.entity.Customers;

/**
 * 
 * @author ravi.pulluri
 *
 */
@Repository
public interface CustomersRepository extends JpaRepository<Customers, String>
{
    List<Customers> findAllByCustleadbankAndCusttypeAndCbeEnabled(final String leadbank, final Character customerType, final Integer cbeEnabled);
    Optional<Customers> findByCustleadbankAndCustcodeAndCusttypeAndCbeEnabled(final String leadbank, final String customerCode, final Character customerType, final Integer cbeEnabled);
}
