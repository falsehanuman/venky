package com.bottomline.cbe.authentication.service;

import java.util.Map;
import java.util.Optional;

import com.bottomline.cbe.authentication.domain.request.EmulationReq;
import com.bottomline.cbe.authentication.domain.response.EmulationSession;

public interface EmulationService
{

	public Map<String, String> listEmulatableCustomers();

	public Map<String, String> listEmulatableUsers(final EmulationReq listUsersReq);

	public Optional<EmulationSession> startEmulation(EmulationReq startEmulationReq);
}
