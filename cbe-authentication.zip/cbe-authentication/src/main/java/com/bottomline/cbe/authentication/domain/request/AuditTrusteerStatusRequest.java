package com.bottomline.cbe.authentication.domain.request;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AuditTrusteerStatusRequest
{

	@JsonProperty(value="auditMessage")
	private String auditMessage;

	public String getAuditMessage()
	{
		return auditMessage;
	}

	public void setAuditMessage(String auditMessage)
	{
		this.auditMessage = auditMessage;
	}
	
	
}
