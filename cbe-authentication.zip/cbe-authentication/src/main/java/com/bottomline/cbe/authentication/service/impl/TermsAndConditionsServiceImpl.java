package com.bottomline.cbe.authentication.service.impl;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bottomline.cbe.authentication.bean.TermsAndConditions;
import com.bottomline.cbe.authentication.service.TermsAndConditionsService;
import com.bottomline.cbe.context.SessionAware;
import com.bottomline.cbe.exception.CBEBusinessException;
import com.magnetbanking.foundation.terms.bo.TermsBo;
import com.magnetbanking.foundation.terms.vo.TermsConditionsVO;
import com.magnetbanking.foundation.users.bo.UserBO;
import com.magnetbanking.foundation.users.vo.UserVO;
import com.magnetbanking.util.exceptions.MagnetSecurityException;

@Service
public class TermsAndConditionsServiceImpl implements TermsAndConditionsService
{

	@Autowired
	TermsBo termsBo;
	@Autowired
	SessionAware sessionVo;

	@Override
	public List<TermsAndConditions> getTcsAndCs()
	{

		Collection<TermsConditionsVO> termsConditionsCollection = termsBo.getTermsForCorpUser(sessionVo.getSessionVo());
		if (termsConditionsCollection != null)
		{
			return termsConditionsCollection.stream().map(list -> {
				TermsAndConditions tsAndcs = new TermsAndConditions();
				tsAndcs.setTermsConditionsId(list.getTerms_cond_id());
				tsAndcs.setTermsConditionsMessage(getBbCodeAsHtml(list.getTerms_cond_msg()));
				tsAndcs.setTermsConditionsName(list.getTerms_cond_name());
				return tsAndcs;
			}).collect(Collectors.toList());
		}
		return null;
	}

	@Override
	public void sendEmailForTsAndCs(UserVO userVO, String tersmAndConditions) throws CBEBusinessException, Exception
	{
		new UserBO().sendEmailForTermsAndCondtions(userVO, tersmAndConditions);
	}

	@Override
	public TermsAndConditions getTsAndCsById(int termsCondsId, boolean includeAudience)
			throws MagnetSecurityException, CBEBusinessException, Exception
	{

		TermsConditionsVO termsConditoins = termsBo.getTermsByIdForWebAPI(termsCondsId, includeAudience);

		TermsAndConditions tsAndcs = new TermsAndConditions();
		if (termsConditoins != null)
			tsAndcs.setTermsConditionsMessage(termsConditoins.getTerms_cond_msg());

		return tsAndcs;
	}

	@Override
	public void userAcceptedTerms(TermsConditionsVO termsConditionsVO)
	{

		termsBo.userAcceptedTerms(termsConditionsVO);
	}

	public void userDeclinedTerms(TermsConditionsVO termsConditionsVO)
	{

		termsBo.userDeclinedTerms(termsConditionsVO);
	}

	public String getBbCodeAsHtml(String msgtext)
	{
		return com.magnetbanking.util.BBCodeToHtml.toHtml(msgtext);
	}

}
