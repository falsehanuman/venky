package com.bottomline.cbe.authentication.service;

import javax.servlet.http.HttpServletRequest;

import com.magnetbanking.foundation.dichallenge.util.DIChallengeUtils.DeviceTokenInfo;

public interface DIChallengeService
{

	public DeviceTokenInfo setDeviceInfo(HttpServletRequest request) throws Exception;

	public boolean generateSecurityKey() throws Exception;

	public boolean validateSecurityKey(String securityKey) throws Exception;
}
