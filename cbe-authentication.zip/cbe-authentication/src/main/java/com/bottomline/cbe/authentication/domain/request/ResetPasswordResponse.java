package com.bottomline.cbe.authentication.domain.request;

public class ResetPasswordResponse {

	private static final long serialVersionUID = 1L;
	
	private String emailId;
	private String phoneNumber;
	
	public String getEmailId()
	{
		return emailId;
	}
	public void setEmailId(String emailId)
	{
		this.emailId = emailId;
	}
	public String getPhoneNumber()
	{
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber)
	{
		this.phoneNumber = phoneNumber;
	}
	
	
}
