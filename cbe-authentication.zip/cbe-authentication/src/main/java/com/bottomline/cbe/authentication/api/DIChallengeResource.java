package com.bottomline.cbe.authentication.api;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bottomline.cbe.authentication.MessageConstants;
import com.bottomline.cbe.authentication.service.DIChallengeService;
import com.bottomline.cbe.context.SessionAware;
import com.bottomline.cbe.exception.CBEBusinessException;
import com.bottomline.cbe.servicescore.annotation.AllowEmulation;
import com.bottomline.cbe.servicescore.domain.response.BasicResponse;
import com.bottomline.cbe.servicescore.domain.response.StandardResponse;
import com.magnetbanking.foundation.dichallenge.util.DIChallengeUtils.DeviceTokenInfo;
import com.magnetbanking.foundation.fraudcheck.util.FraudCheckRequestUtils;
import com.magnetbanking.foundation.logon.web.LogonUtils;
import com.magnetbanking.foundation.session.filter.ChallengeUtils;
import com.magnetbanking.foundation.session.iface.BadSession;
import com.magnetbanking.ibs.ecomAPIPackage.ExceptionUserNotFound;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/dichallenge")
public class DIChallengeResource
{

	@Autowired
	SessionAware session;

	@Autowired
	DIChallengeService service;
	
	@Autowired
	FraudCheckRequestUtils fraudCheckRequestUtils;

	@RequestMapping(value = "/remeberDevice", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	@ApiOperation(value = "Set Device Information", notes = "Sets the device information to remember it for next login")
	public StandardResponse<DeviceTokenInfo> remeberDevice(HttpServletRequest request) throws Exception
	{
		StandardResponse<DeviceTokenInfo> resp = new StandardResponse<DeviceTokenInfo>();

		DeviceTokenInfo deviceInfo = service.setDeviceInfo(request);

		resp.setData(deviceInfo);
		resp.setResponseOK();
		return resp;
	}

	@RequestMapping(value = "/generateSecurityKey", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	@ApiOperation(value = "Set security challenge key", notes = "Sets the security challenge key and send it to user via email")
	public BasicResponse generateSecurityKey() throws Exception
	{

		BasicResponse resp = new BasicResponse();

		Boolean result = service.generateSecurityKey();

		resp.setResponseOK("Device optionce set Successfully");
		resp.setResponseOK();
		return resp;
	}

	@ApiOperation(value = "Validate Security key", notes = "Validates the Security key against the one recieved in the email")
	@RequestMapping(value = "/validateSecurityKey", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	@AllowEmulation
	public BasicResponse validateSecurityKey(@Valid @RequestBody @NotBlank String securityKey)
			throws BadSession, ExceptionUserNotFound, Exception
	{

		BasicResponse resp = new BasicResponse();

		boolean success = service.validateSecurityKey(securityKey.trim());
		if (success)
		{
			resp.setResponseOK();
			
			fraudCheckRequestUtils.populateAuthAndSendLoginEventIfFCEnabled(LogonUtils.LogonStatus.SUCCESSFUL,
				  "Success", ChallengeUtils.ChallengeReason.DEVICE_UNRECOGNIZED, session.getSessionVo());
		}
		else
		{
			fraudCheckRequestUtils.populateAuthAndSendLoginEventIfFCEnabled(LogonUtils.LogonStatus.FAILED_AUTHENTICATION,
				  "Fail", ChallengeUtils.ChallengeReason.DEVICE_UNRECOGNIZED, session.getSessionVo());
			
			throw new CBEBusinessException(MessageConstants.INVALID_SECURITY_KEY, "Invalid Security Key");
		}

		return resp;
	}
}
