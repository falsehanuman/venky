package com.bottomline.cbe.authentication.domain.request;

import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.NotNull;

import com.bottomline.cbe.authentication.domain.request.ViewTypeRequest.ViewType;

public class SecurityContactRequest implements Serializable
{
	@NotNull
	List<SecurityContact> securityContacts;
	public List<SecurityContact> getSecurityContacts()
	{
		return securityContacts;
	}
	public void setSecurityContacts(List<SecurityContact> securityContacts)
	{
		this.securityContacts = securityContacts;
	}
	public ViewType getViewType()
	{
		return viewType;
	}
	public void setViewType(ViewType viewType)
	{
		this.viewType = viewType;
	}
	@NotNull
	public ViewType viewType;
	
		
}
