package com.bottomline.cbe.authentication.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bottomline.cbe.authentication.domain.response.TrusteerSysOptionsResponse;
import com.bottomline.cbe.authentication.service.SecurityService;
import com.bottomline.cbe.context.FIContextAware;
import com.bottomline.cbe.context.LeadbankAware;
import com.magnetbanking.foundation.infrastructure.option.impl.OptionManager;
import com.magnetbanking.foundation.infrastructure.option.vo.OptionDefault;

@Service
public class SecurityServiceImpl implements SecurityService
{
	
	@Autowired
	LeadbankAware leadbankAware;
	
	@Autowired
	FIContextAware fiContextAware;
	
	public TrusteerSysOptionsResponse getTrusteerSysOptions()
	{
		TrusteerSysOptionsResponse response = new TrusteerSysOptionsResponse();
		if (leadbankAware.getLeadbankId() != null)
		{
			response.setSnippetId(OptionManager.getOption(OptionDefault.TRUSTEER_SNIPPET_ID, leadbankAware.getLeadbankId()));
			response.setRapportEnabled(
				OptionManager.getOption(OptionDefault.TRUSTEER_RAPPORT_LOCATION, leadbankAware.getLeadbankId()));
			response.setPinpointEnabled(
				new Boolean(OptionManager.getOption(OptionDefault.TRUSTEER_PINPOINT_SNIPPET_ID, leadbankAware.getLeadbankId())));
			response.setPinPointURL(OptionManager.getOption(OptionDefault.TRUSTEER_PINPOINT_URL, leadbankAware.getLeadbankId()));
			response
				.setRapportServer(OptionManager.getOption(OptionDefault.TRUSTEER_RAPPORT_SERVER, leadbankAware.getLeadbankId()));
			response.setMessage(
				OptionManager.getOption(OptionDefault.TRUSTEER_MANDATORY_INSTALL_MESSAGE, leadbankAware.getLeadbankId()));
			response.setSharedKey(OptionManager.getOption(OptionDefault.TRUSTEER_API_SHARED_KEY, leadbankAware.getLeadbankId()));
			response.setTenantId(fiContextAware.getMasterFi());
			
			//currently below values are not managed in BFS options and these needs to fix whenever they added in admin site
			response.setCallBackMethod("getInfo");
			response.setDefaultTag("login");
		}
		
		return response;
	}
}

