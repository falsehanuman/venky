package com.bottomline.cbe.authentication.domain.response;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.bottomline.cbe.challengemanager.ChallengePoint;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 *
 * @author ravi.pulluri
 *
 */

@JsonPropertyOrder({ "authenticationId", "isFirstLogin", "mustChangePassword", "passwordExpirationDays",
	"showPasswordExpirationWarning", "showLicenseWarning" })

public class AuthenticationResponse implements Serializable
{

	private static final long serialVersionUID = 1L;

	@JsonProperty("authenticationId")
	private String authenticationId;

	@JsonProperty("mustChangePassword")
	private boolean changePassword;

	@JsonProperty("passwordExpirationDays")
	private int pwdExpirationDays;

	@JsonProperty("showPasswordExpirationWarning")
	private boolean showPasswdExpWarning;

	@JsonProperty("showLicenseWarning")
	private boolean showLicenseWarning;

	@JsonProperty("isFirstLogin")
	private boolean firstLogin;

	@JsonProperty("isSecurityAnsNeeded")
	private boolean secAnsNeeded;

	@JsonFormat(shape = JsonFormat.Shape.STRING)
	@JsonProperty("lastLoginTime")
	private Date lastloginTime;

	@JsonProperty("userName")
	private String userName;

	@JsonProperty("userCode")
	private String userCode;

	@JsonProperty("customerCode")
	private String custCode;

	@JsonProperty("hasTermsAndConditions")
	private boolean hasTermsAndConditions;

	@JsonProperty("securityContactRequired")
	private boolean securityContactRequired;

	@JsonProperty("isMfaEnabled")
	private boolean mfaEnabled;

	@JsonProperty("userInformation")
	private UserInformationResponse userInformation;

	@JsonProperty("deviceInfoAvailable")
	private boolean deviceInfoAvailable = true;

	@JsonProperty("deviceInfoEnabled")
	private boolean deviceInfoEnabled;

	@JsonProperty("bankUser")
	private boolean bankUser;

	@JsonProperty("emulationSession")
	private boolean emulationSession;

	@JsonProperty("channel")
	private String channel;

	private String timeZone;

	private boolean voiceEnabled;

	public boolean getBankUser()
	{
		return bankUser;
	}

	public void setBankUser(boolean bankUser)
	{
		this.bankUser = bankUser;
	}

	public void setEmulationSession(boolean emulationSession) {
		this.emulationSession = emulationSession;
	}

	public boolean isEmulationSession() {
		return emulationSession;
	}

	public boolean isSecurityContactRequired()
	{
		return securityContactRequired;
	}

	public void setSecurityContactRequired(boolean securityContactRequired)
	{
		this.securityContactRequired = securityContactRequired;
	}

	public boolean isHasTermsAndConditions()
	{
		return hasTermsAndConditions;
	}

	public void setHasTermsAndConditions(boolean hasTermsAndConditions)
	{
		this.hasTermsAndConditions = hasTermsAndConditions;
	}

	public String getUserCode()
	{
		return userCode;
	}

	public void setUserCode(String userCode)
	{
		this.userCode = userCode;
	}

	public String getCustCode()
	{
		return custCode;
	}

	public void setCustCode(String custCode)
	{
		this.custCode = custCode;
	}

	public Date getLastloginTime()
	{
		return lastloginTime;
	}

	public void setLastloginTime(Date lastloginTime)
	{
		this.lastloginTime = lastloginTime;
	}

	public String getUserName()
	{
		return userName;
	}

	public void setUserName(String userName)
	{
		this.userName = userName;
	}

	public String getAuthenticationId()
	{
		return authenticationId;
	}

	public boolean isChangePassword()
	{
		return changePassword;
	}

	public int getPwdExpirationDays()
	{
		return pwdExpirationDays;
	}

	public boolean isShowPasswdExpWarning()
	{
		return showPasswdExpWarning;
	}

	public boolean isShowLicenseWarning()
	{
		return showLicenseWarning;
	}

	public boolean isFirstLogin()
	{
		return firstLogin;
	}

	public boolean isSecAnsNeeded()
	{
		return secAnsNeeded;
	}

	public void setAuthenticationId(String authenticationId)
	{
		this.authenticationId = authenticationId;
	}

	public void setChangePassword(boolean changePassword)
	{
		this.changePassword = changePassword;
	}

	public void setPwdExpirationDays(int pwdExpirationDays)
	{
		this.pwdExpirationDays = pwdExpirationDays;
	}

	public void setShowPasswdExpWarning(boolean showPasswdExpWarning)
	{
		this.showPasswdExpWarning = showPasswdExpWarning;
	}

	public void setShowLicenseWarning(boolean showLicenseWarning)
	{
		this.showLicenseWarning = showLicenseWarning;
	}

	public void setFirstLogin(boolean firstLogin)
	{
		this.firstLogin = firstLogin;
	}

	public void setSecAnsNeeded(boolean secAnsNeeded)
	{
		this.secAnsNeeded = secAnsNeeded;
	}

	public UserInformationResponse getUserInformation()
	{
		return userInformation;
	}

	public void setUserInformation(UserInformationResponse userInformation)
	{
		this.userInformation = userInformation;
	}

	public boolean isDeviceInfoAvailable()
	{
		return deviceInfoAvailable;
	}

	public void setDeviceInfoAvailable(boolean deviceInfoAvailable)
	{
		this.deviceInfoAvailable = deviceInfoAvailable;
	}

	public boolean isMfaEnabled()
	{
		return mfaEnabled;
	}

	public void setMfaEnabled(boolean mfaEnabled)
	{
		this.mfaEnabled = mfaEnabled;
	}

	public boolean isDeviceInfoEnabled()
	{
		return deviceInfoEnabled;
	}

	public void setDeviceInfoEnabled(boolean deviceInfoEnabled)
	{
		this.deviceInfoEnabled = deviceInfoEnabled;
	}

	public String getChannel()
	{
		return channel;
	}

	public void setChannel(String channel)
	{
		this.channel = channel;
	}

	public String getTimeZone()
	{
		return timeZone;
	}

	public void setTimeZone(String timeZone)
	{
		this.timeZone = timeZone;
	}

	public boolean isVoiceEnabled()
	{
		return voiceEnabled;
	}

	public void setVoiceEnabled(boolean voiceEnabled)
	{
		this.voiceEnabled = voiceEnabled;
	}

	@Override
	public String toString()
	{
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}


	@JsonIgnore
	public String getChallengePointServiceCode()
	{
		if(isDeviceInfoEnabled() && !isDeviceInfoAvailable())
		{
			return ChallengePoint.LOGIN_FROM_UNREGISTERED_DEVICE.getSvcCode();
		}
		if(isDeviceInfoEnabled() && isFirstLogin())
		{
			return ChallengePoint.LOGIN_FROM_UNREGISTERED_DEVICE.getSvcCode();
		}
		return ChallengePoint.LOGIN.getSvcCode();
	}

}
