package com.bottomline.cbe.authentication.service.impl;

import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bottomline.cbe.authentication.service.DIChallengeService;
import com.bottomline.cbe.context.SessionAware;
import com.bottomline.cbe.otp.domain.MfaCode;
import com.bottomline.cbe.otp.domain.MfaCodePK;
import com.bottomline.cbe.otp.persistence.MfaCodeDao;
import com.magnetbanking.foundation.dichallenge.util.DIChallengeUtils;
import com.magnetbanking.foundation.dichallenge.util.DIChallengeUtils.DeviceTokenInfo;
import com.magnetbanking.foundation.infrastructure.option.vo.OptionDefault;
import com.magnetbanking.foundation.leadbank.dao.LeadbankDAO;
import com.magnetbanking.foundation.leadbank.vo.LeadbankVO;
import com.magnetbanking.foundation.users.bo.UserBO;
import com.magnetbanking.foundation.users.dao.UserDAO;
import com.magnetbanking.foundation.users.vo.UserVO;
import com.magnetbanking.util.MibsUtils;
import com.magnetbanking.util.StringUtils;
import com.magnetbanking.util.exceptions.NoSuchVOException;

@Service
public class DIChallengeServiceImpl implements DIChallengeService
{

	@Autowired
	SessionAware session;

	@Autowired
	MfaCodeDao mfaCodeDao;

	@Autowired
	UserDAO userDao;

	@Autowired
	UserBO userBo;

	@Autowired
	LeadbankDAO leadbankDao;
	
	@Autowired DIChallengeUtils diChallenge;

	/**
	 * This method stores the device challenge into database
	 */
	public DeviceTokenInfo setDeviceInfo(HttpServletRequest request) throws Exception
	{

		DeviceTokenInfo deviceTokenInfo = diChallenge.setCookie(request, session.getSessionVo());
		return deviceTokenInfo;

	}

	/**
	 * This method is used to generate a Security key to challenge the user. An email will be send to User with security key.
	 */
	public boolean generateSecurityKey() throws Exception
	{

		String generateKey = MibsUtils.generateNumeric(6);


		MfaCode mfaCode = new MfaCode();
		mfaCode.setMfacode(generateKey);
		MfaCodePK mfaCodePK = new MfaCodePK();
		mfaCodePK.setSessId(session.getSessionId());
		mfaCode.setId(mfaCodePK);
		//mfaCode.setPasswordexpdate(new Timestamp(System.currentTimeMillis() + TimeUnit.MINUTES.toMillis(session.getSession().getInactivityWarningLeadTime())));
		mfaCodeDao.save(mfaCode);

		UserVO userVo = userDao.getUserByCodes(session.getCustomerCode(), session.getUserCode());

		String subject = "Login key for " + getFiName();
		String message = "You have initiated a login to " + getFiName()
				+ ".  The Login Key required is shown below, please copy and paste it onto the login screen.\r\n" + "\r\n"
				+ "If you believe that you have received this email in error, please contact your Company or Bank Administrator immediately.  Please do not reply to this email.\r\n"
				+ "\r\n" + "Login Key:  " + generateKey;

		userBo.sendEmailDIChallengeKey(session.getSessionVo(), userVo, generateKey, subject, message);

		return true;

	}

	/**
	 * This method validates the device security key entered by user
	 * 
	 * @return
	 * @throws Exception
	 */
	public boolean validateSecurityKey(String securityKey) throws Exception
	{

		MfaCodePK mfaCodePK = new MfaCodePK();
		mfaCodePK.setSessId(session.getSessionId());
		Optional<MfaCode> activeMfaCode = mfaCodeDao.findById(mfaCodePK);
		if (activeMfaCode.isPresent())
		{
			String mfaActivationCode = activeMfaCode.map(MfaCode::getMfacode).orElse("");
			if (mfaActivationCode.equals(securityKey))
			{
				return true;
			}

		}
		return false;

	}

	private String getFiName() throws NoSuchVOException
	{
		// first check to see if they have set the system option to
		// determine the FI name, if not, then use the leadbank name
		LeadbankVO leadbank = leadbankDao.getLeadbank(session.getLeadbankId());

		String fiName = null;

		fiName = com.magnetbanking.foundation.infrastructure.option.impl.OptionManager
			.getOption(OptionDefault.MOBILE_BANK_NAME.getId(), leadbank.getId()).getValue();

		if (StringUtils.isEmpty(fiName))
		{
			fiName = leadbank.getName();
		}
		return fiName;
	}
}
