package com.bottomline.cbe.authentication.bean;

public class TermsAndConditions {

	

	private Integer termsConditionsId;
	private String termsConditionsMessage;
	private String termsConditionsName;
	
	public String getTermsConditionsName()
	{
		return termsConditionsName;
	}
	public void setTermsConditionsName(String termsConditionsName)
	{
		this.termsConditionsName = termsConditionsName;
	}
	public Integer getTermsConditionsId() {
		return termsConditionsId;
	}
	public void setTermsConditionsId(Integer termsConditionsId) {
		this.termsConditionsId = termsConditionsId;
	}
	public String getTermsConditionsMessage() {
		return termsConditionsMessage;
	}
	public void setTermsConditionsMessage(String termsConditionsMessage) {
		this.termsConditionsMessage = termsConditionsMessage;
	}
	
}
