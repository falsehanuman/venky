package com.bottomline.cbe.authentication;

import org.apache.catalina.connector.Connector;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.servlet.server.ServletWebServerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import com.bottomline.cbe.bootstrap.MvcServletConfig;

@SpringBootApplication
@EnableAspectJAutoProxy
public class CBEAuthenticationStartup {
    private static final String ENVIRONMENT_NAME = "CBE_ENV";
    
    @Value("${http.port}")
    private int httpPort;

    public static void main(String[] args) {
        final String environment = System.getenv(ENVIRONMENT_NAME);
        if (StringUtils.isNotBlank(environment)) {
            System.out.println("starting for environment:" + environment);
            new SpringApplicationBuilder().profiles(environment).sources(MvcServletConfig.class).run(args);
        } else {
            final String profile = System.getProperty("spring.profiles.active");
            if (StringUtils.isNotBlank(profile)) {
                System.out.println("starting for environment:" + profile);
                new SpringApplicationBuilder().profiles(profile).sources(MvcServletConfig.class).run(args);
            } else {
                System.out.println("Use -Dspring.profiles.active or missing CBE_ENV environment variable");
                throw new RuntimeException("Profile/Environment is missing. ");
            }
        }
    }
    
	// Let's configure additional connector to enable support for both HTTP and HTTPS
	@Bean
	public ServletWebServerFactory servletContainer() {
		TomcatServletWebServerFactory tomcat = new TomcatServletWebServerFactory();
		tomcat.addAdditionalTomcatConnectors(createStandardConnector());
		return tomcat;
	}

	private Connector createStandardConnector() {
		Connector connector = new Connector("org.apache.coyote.http11.Http11NioProtocol");
		connector.setPort(httpPort);
		return connector;
	}
}
