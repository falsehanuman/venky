package com.bottomline.cbe.authentication.domain.request;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import io.swagger.annotations.ApiModelProperty;

@JsonPropertyOrder({ "question1Id", "question2Id", "question3Id","answer1", "answer2", "answer3" })
public class ResetPasswordRequest extends UserResourceRequest {
	private static final long serialVersionUID = 1L;

	private String answer1;
	private String answer2;
	private String answer3;
	private int question1Id;
	private int question2Id;
	private int question3Id;

	public String getAnswer1() {
		return answer1;
	}
	public void setAnswer1(String answer1) {
		this.answer1 = answer1;
	}
	public String getAnswer2() {
		return answer2;
	}
	public void setAnswer2(String answer2) {
		this.answer2 = answer2;
	}
	public String getAnswer3() {
		return answer3;
	}
	public void setAnswer3(String answer3) {
		this.answer3 = answer3;
	}
	public int getQuestion1Id() {
		return question1Id;
	}
	public void setQuestion1Id(int question1Id) {
		this.question1Id = question1Id;
	}
	public int getQuestion2Id() {
		return question2Id;
	}
	public void setQuestion2Id(int question2Id) {
		this.question2Id = question2Id;
	}
	public int getQuestion3Id() {
		return question3Id;
	}
	public void setQuestion3Id(int question3Id) {
		this.question3Id = question3Id;
	}	
	
}
