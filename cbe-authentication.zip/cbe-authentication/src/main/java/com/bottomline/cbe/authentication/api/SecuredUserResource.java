package com.bottomline.cbe.authentication.api;

import static com.bottomline.cbe.servicescore.interceptor.AuthorizationCheckInterceptor.AUTHORIZATION;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bottomline.cbe.authentication.MessageConstants;
import com.bottomline.cbe.authentication.bean.SecurityQuestion;
import com.bottomline.cbe.authentication.domain.request.OneTimePasscodeRequest;
import com.bottomline.cbe.authentication.domain.request.PasswordResetRequest;
import com.bottomline.cbe.authentication.domain.request.SecurityContact;
import com.bottomline.cbe.authentication.domain.request.SecurityContactRequest;
import com.bottomline.cbe.authentication.domain.request.SecurityContactResponse;
import com.bottomline.cbe.authentication.domain.request.SecurityQsAnsRequest;
import com.bottomline.cbe.authentication.domain.request.UserInformationRequest;
import com.bottomline.cbe.authentication.domain.request.ViewTypeRequest;
import com.bottomline.cbe.authentication.domain.response.PasswordComplexityResponse;
import com.bottomline.cbe.authentication.domain.response.SecurityQuestionsResponse;
import com.bottomline.cbe.authentication.domain.response.UserResourceResponse;
import com.bottomline.cbe.authentication.jpa.LoginChallengeRepository;
import com.bottomline.cbe.authentication.jpa.entity.LoginChallenge;
import com.bottomline.cbe.authentication.service.AuthenticationService;
import com.bottomline.cbe.challengemanager.ChallengeManager;
import com.bottomline.cbe.challengemanager.ChallengePoint;
import com.bottomline.cbe.context.SessionAware;
import com.bottomline.cbe.exception.CBEBusinessException;
import com.bottomline.cbe.servicescore.annotation.AllowEmulation;
import com.bottomline.cbe.servicescore.annotation.AllowedServices;
import com.bottomline.cbe.servicescore.annotation.Challengeable;
import com.bottomline.cbe.servicescore.annotation.PublicApi;
import com.bottomline.cbe.servicescore.domain.response.BasicResponse;
import com.bottomline.cbe.servicescore.domain.response.StandardResponse;
import com.bottomline.cbe.servicescore.util.CBEContextAwareBeanLoader;
import com.magnetbanking.foundation.challengemanager.providers.mfa2.bo.NSClientBo;
import com.magnetbanking.foundation.challengemanager.providers.mfa2.vo.Destination;
import com.magnetbanking.foundation.challengemanager.providers.mfa2.vo.DestinationWebWrapper;
import com.magnetbanking.foundation.fraudcheck.enums.FraudCheckBunchEnum;
import com.magnetbanking.foundation.fraudcheck.ga.enums.GAPasswordChangeReason;
import com.magnetbanking.foundation.fraudcheck.util.FraudCheckRequestUtils;
import com.magnetbanking.foundation.leadbank.dao.LeadbankDAO;
import com.magnetbanking.foundation.leadbank.vo.LeadbankVO;
import com.magnetbanking.foundation.logon.web.LogonUtils;
import com.magnetbanking.foundation.services.iface.Service;
import com.magnetbanking.foundation.session.filter.ChallengeUtils;
import com.magnetbanking.foundation.session.iface.BadSession;
import com.magnetbanking.foundation.users.vo.UserInfoVO;
import com.magnetbanking.foundation.users.vo.UserVO;
import com.magnetbanking.ibs.ecomAPIPackage.ExceptionUserNotFound;
import com.magnetbanking.util.exceptions.InvalidDataException;
import com.magnetbanking.util.exceptions.WrapperException;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@RequestMapping("/user")
public class SecuredUserResource
{

	@Autowired
	AuthenticationService authenticationService;

	@Autowired
	UsersResource userResource;

	@Autowired
	SessionAware session;

	@Autowired
	LeadbankDAO leadbankDAO;

	@Autowired
	NSClientBo nsClient;

	@Autowired
	ChallengeManager challengeManager;
	
	@Autowired
	FraudCheckRequestUtils fraudCheckRequestUtils;

	@Autowired private CBEContextAwareBeanLoader cbeContextBeanLoader;
	@Autowired private LoginChallengeRepository loginChallengeRepository;

	@ApiOperation(value = "Retrieves Security Questions", notes = "Retrieves Security Questions for the User.")
	@RequestMapping(value = "/getSecurityQuestions", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	@AllowEmulation
	public StandardResponse<SecurityQuestionsResponse> getUserSecurityQuestion() throws Exception
	{

		//return userResource.getUserSecurityQuestion(request, br, httpRequest, response);
		//userResource.validateUserAndCustomerIds(session.getCustomerCode(), session.getUserCode());

		final StandardResponse<SecurityQuestionsResponse> resp = new StandardResponse<SecurityQuestionsResponse>();

		final UserVO userVo = userResource.getUserVO(session.getCustomerCode(), session.getUserCode());

		userResource.validateUserIsEnabled(userVo, session.getCustomerCode());

		final UserInfoVO userInfoVO = authenticationService.getUserSecurityInformation(userVo.getCustId(), userVo.getId());
		userResource.validateSecurityQuestions(userVo, userInfoVO);

		final List<SecurityQuestion> securityQuestions = new ArrayList<SecurityQuestion>();

		final SecurityQuestion question1 = new SecurityQuestion();
		question1.setQuestionId(new Long(userInfoVO.getQuestion1Id()));
		question1.setQuestion(authenticationService.getSecurityQuestion(userInfoVO.getQuestion1Id()));

		final SecurityQuestion question2 = new SecurityQuestion();
		question2.setQuestionId(new Long(userInfoVO.getQuestion2Id()));
		question2.setQuestion(authenticationService.getSecurityQuestion(userInfoVO.getQuestion2Id()));

		final SecurityQuestion question3 = new SecurityQuestion();
		question3.setQuestionId(new Long(userInfoVO.getQuestion3Id()));
		question3.setQuestion(authenticationService.getSecurityQuestion(userInfoVO.getQuestion3Id()));

		securityQuestions.add(question1);
		securityQuestions.add(question2);
		securityQuestions.add(question3);

		final SecurityQuestionsResponse securityQuestionsResponse = new SecurityQuestionsResponse();
		securityQuestionsResponse.setSecurityQuestions(securityQuestions);

		resp.setData(securityQuestionsResponse);
		resp.setResponseOK();
		return resp;

	}

	@ApiOperation(value = "Retrieves Security Questions", notes = "Retrieves all Security Questions defined by the Lead Bank.")
	@RequestMapping(value = "/getSecurityQuestionsByLeadBank", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@AllowEmulation
	public StandardResponse<SecurityQuestionsResponse> fetchSecurityQuestionsForLeadBank() throws CBEBusinessException, Exception
	{

		final StandardResponse<SecurityQuestionsResponse> resp = new StandardResponse<SecurityQuestionsResponse>();

		final LeadbankVO leadbankVO = new LeadbankDAO().getLeadbank(session.getLeadbankCode());
		if ((leadbankVO == null) || (leadbankVO.getId() == null))
		{
			throw new CBEBusinessException(MessageConstants.LEADBANK_NOT_FOUND, "Leadbank code is not found in the system");
		}

		final List<SecurityQuestion> securityQuestionsList = authenticationService
				.fetchSecurityQuestionsForLeadBank(leadbankVO.getId());

		if ((securityQuestionsList == null) || securityQuestionsList.isEmpty())
		{
			throw new CBEBusinessException(MessageConstants.NO_SECURITY_QUESTIONS, "Security questions not set");
		}

		final SecurityQuestionsResponse securityQuestionsResponse = new SecurityQuestionsResponse();
		securityQuestionsResponse.setSecurityQuestions(securityQuestionsList);

		resp.setData(securityQuestionsResponse);
		resp.setResponseOK();
		return resp;
	}

	@ApiOperation(value = "Save or Update Security Questions and Answers", notes = "Save if Security Questions and Answers submitted first time, else Update existing Security Question and Answers")
	@RequestMapping(value = "/saveSecurityQuestionAnswers", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	public StandardResponse<UserResourceResponse> updateSecurityQuestionAnswers(
			@Valid @RequestBody @ApiParam final SecurityQsAnsRequest request) throws Exception
	{

		final UserInfoVO userInfoVO = new UserInfoVO();
		final StandardResponse<UserResourceResponse> resp = new StandardResponse<UserResourceResponse>();

		//userResource.validateUserAndCustomerIds(session.getCustomerCode(), session.getUserCode());
		final UserVO userVo = userResource.getUserVO(session.getCustomerCode(), session.getUserCode());
		//userResource.validateUserIsEnabled(userVo);

		userInfoVO.setCustId(userVo.getCustId());
		userInfoVO.setUserId(userVo.getId());
		userInfoVO.setQuestion1Id(request.getQuestion1Id());
		userInfoVO.setQuestion2Id(request.getQuestion2Id());
		userInfoVO.setQuestion3Id(request.getQuestion3Id());
		userInfoVO.setSecurityAnswer1(request.getAnswer1());
		userInfoVO.setSecurityAnswer2(request.getAnswer2());
		userInfoVO.setSecurityAnswer3(request.getAnswer3());

		/* Condition to verify the User request to see if it is Save or Update */
		final UserInfoVO userInfo = authenticationService.getUserSecurityInformation(userVo.getCustId(), userVo.getId());
		if (null == userInfo)
		{
			authenticationService.addSecurityQuestionAnswers(userInfoVO);
		}
		else
		{
			authenticationService.updateSecurityQuestionAnswers(userInfoVO);
		}

		final String userMessage = "Security QuetionsAnswers were successfully saved to database.";
		resp.setResponseOK(userMessage, "Security QuestionAnswers saved successfully");
		return resp;
	}

	@ApiOperation(value = "Retrieves Password Complexity Requirements", notes = "Retrieves Password Complexity Requirements defined by the Lead Bank")
	@AllowEmulation
	@RequestMapping(value = "/getPwdComplexityRequirements", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public StandardResponse<PasswordComplexityResponse> fetchPasswordComplexityRequirements()
			throws CBEBusinessException, Exception
	{

		final StandardResponse<PasswordComplexityResponse> resp = new StandardResponse<PasswordComplexityResponse>();
		final LeadbankVO leadbankVO = new LeadbankDAO().getLeadbank(session.getLeadbankCode());

		if ((leadbankVO == null) || (leadbankVO.getId() == null))
		{
			throw new CBEBusinessException(MessageConstants.LEADBANK_NOT_FOUND, "Leadbank code is not found in the system");
		}
		final String passwordPattern = authenticationService.fetchPasswordPattern(leadbankVO.getId());
		final String passwordPatternDescription = authenticationService.fetchPasswordPatternDescription(leadbankVO.getId());
		final List<String> passwordInclusions = authenticationService.fetchPasswordInclusions(leadbankVO.getId());

		final PasswordComplexityResponse passwordComplexityResponse = new PasswordComplexityResponse();
		passwordComplexityResponse.setLbCode(session.getLeadbankCode());
		passwordComplexityResponse.setCustCode(session.getCustomerCode());
		passwordComplexityResponse.setUserCode(session.getUserCode());
		passwordComplexityResponse.setPasswordPattern(passwordPattern);
		passwordComplexityResponse.setPasswordPatternDescription(passwordPatternDescription);
		passwordComplexityResponse.setMinPasswordLength(leadbankVO.getMinPswdLen().intValue());
		passwordComplexityResponse.setMaxCustPasswordLength(leadbankVO.getMaxCustPswdLen().intValue());
		passwordComplexityResponse.setMaxUserPasswordLength(leadbankVO.getMaxUserPswdLen().intValue());
		passwordComplexityResponse.setPasswordHistoryLength(leadbankVO.getPswdHistMax().intValue());
		passwordComplexityResponse.setPasswordExpireDays(leadbankVO.getPswdExpireDays().intValue());
		passwordComplexityResponse.setPasswordExpireWarn(leadbankVO.getPswdExpireWarn().intValue());
		passwordComplexityResponse.setPasswordInclusions(passwordInclusions);

		resp.setData(passwordComplexityResponse);
		resp.setResponseOK();
		return resp;
	}

	@ApiOperation(value = "Change Password", notes = "Change Password for the User.")
	@RequestMapping(value = "/changePassword", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public BasicResponse resetPassword(@Valid @RequestBody final PasswordResetRequest request)
			throws CBEBusinessException, Exception
	{

		final BasicResponse resp = new BasicResponse();

		authenticationService.changePassword(session.getCustomerCode(), session.getUserCode(), request.getOldPassword(),
			request.getNewPassword());

		final String userMessage = "Change password is success";
		resp.setResponseOK(userMessage, "Passwod changed Successfully");
		
		fraudCheckRequestUtils.fraudCheckPasswordChange(GAPasswordChangeReason.ADMIN_RESET.getApiValue(), session.getSessionVo());
		
		return resp;
	}

	@ApiOperation(value = "Updates User information", notes = "Allows User  with SelfAdmin service to Update their own Information as well as Admin  to update the information of the users in their hierarchy")
	@AllowedServices(value = { Service.SELFADMIN }, apiService = Service.SELFADMIN)
	@RequestMapping(value = "/updateUserInfo", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	@Challengeable(challengePoint = ChallengePoint.SELF_ADMIN)
	public StandardResponse<?> updatesUserInfo(@Valid @RequestBody UserInformationRequest userInformationRequest)
			throws BadSession, ExceptionUserNotFound, Exception
	{

		final StandardResponse<?> resp = new StandardResponse<>();

		/*
		 * // FIXME Use @AllowedServices to define audit service.
		 *
		 * session.getMagnetSession() .setService(new ServiceVO(0, Service.SELFADMIN.getCode(), "", "SelfAdmin", ServiceVO.BOTH,
		 * ServiceVO.NEITHER), true);
		 */

		final UserVO userVO = authenticationService.getUserInformation(userInformationRequest.getCustCode(),
			userInformationRequest.getUserCode());
		
		UserVO oldUserVO = userVO.clone();
		
		userVO.setName(userInformationRequest.getUserName());
		userVO.setAddress1(userInformationRequest.getAddress1());
		userVO.setAddress2(userInformationRequest.getAddress2());
		userVO.setCity(userInformationRequest.getCity());
		userVO.setState(userInformationRequest.getState());
		userVO.setZip(userInformationRequest.getPostalCode());
		userVO.setVoicePhone(userInformationRequest.getVoicePhone());
		userVO.setFaxPhone(userInformationRequest.getFaxNumber());
		userVO.setEmail(userInformationRequest.getEmail());

		authenticationService.updateUserInformation(userVO);
		
		//FraudMap integration
		fraudCheckRequestUtils.fraudCheckCreateOrEditUser(oldUserVO, FraudCheckBunchEnum.USER_EDIT_EVENTS);
		
		resp.setResponseOK();
		return resp;
	}

	@ApiOperation(value = "Retrieves User  Security information", notes = "Retrieves User  Security information")
	@AllowEmulation
	@RequestMapping(value = "/retrievesUserSecurityInfo", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	public BasicResponse getUserSecurityContact(@RequestBody(required = true) ViewTypeRequest view)
			throws BadSession, ExceptionUserNotFound, Exception
	{

		final StandardResponse<List<SecurityContactResponse>> resp = new StandardResponse<List<SecurityContactResponse>>();
		final UserVO userVo = authenticationService.getUserInformation(session.getCustomerCode(), session.getUserCode());

		if (nsClient.isMFA2Enabled(leadbankDAO.getLeadbank(session.getLeadbankCode()), session.getSessionVo()))
		{

			final List<DestinationWebWrapper> destinationWrapperLst = authenticationService.getUserSecurityContactInformation(userVo,
				view);

			if (destinationWrapperLst != null)
			{
				final List<SecurityContactResponse> secContactResponses = destinationWrapperLst.stream().map(d -> {
					final SecurityContactResponse s = new SecurityContactResponse();
					s.setContactType(d.getProtocol());
					s.setValue(d.getAddress());
					s.setDefault(d.getIsDefault());
					if (Destination.Protocol.VOICE.equals(d.getProtocol()))
					{
						final String address = d.getAddress();
						if ((address != null) && (address.length() > 10) && address.contains(","))
						{
							s.setValue(address.substring(0, address.indexOf(",")));
							s.setVruDelay((address.lastIndexOf(",") - 9) * 2);
							s.setExtension(address.substring(address.lastIndexOf(",") + 1));
						}
					}
					return s;
				}).collect(Collectors.toList());
				resp.setData(secContactResponses);
			}
		}

		resp.setResponseOK();
		return resp;
	}

	@ApiOperation(value = "Checks user is enabled for OTP", notes = "Checks if the user is enabled for OTP Multi factor Authentication")
	@RequestMapping(value = "/checkMFA2Enabled", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	public BasicResponse checkMFA2Enabled() throws BadSession, ExceptionUserNotFound, Exception
	{

		final StandardResponse<Boolean> resp = new StandardResponse<Boolean>();
		resp.setData(nsClient.isMFA2Enabled(leadbankDAO.getLeadbank(session.getLeadbankCode()), session.getSessionVo()));
		resp.setResponseOK();
		return resp;
	}

	@ApiOperation(value = "Updates User Security Contact Information", notes = "Allows User to Update the Security Contact Information")
	@RequestMapping(value = "/updatesSecurityContactInfo", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	@Challengeable(challengePointMethod = "provideChallengePointServiceCodesFor_updatesSecurityContactInfo")
	public StandardResponse<?> updatesSecurityContactInfo(
			@Valid @RequestBody @NotNull SecurityContactRequest securityContactRequests)
					throws BadSession, ExceptionUserNotFound, Exception
	{

		final StandardResponse<?> resp = new StandardResponse<>();
		final List<SecurityContact> securityContacts = securityContactRequests.getSecurityContacts();
		if (!securityContacts.isEmpty())
		{
			final long defaultContactCnt = securityContacts.stream().filter(s -> s.isDefault() == true).count();
			if (defaultContactCnt == 1)
			{
				final List<Destination> combinedDestinations = securityContacts.stream().map(s -> {

					final Destination dest = new Destination(s.getValue(), s.getContactType());
					if (Destination.Protocol.VOICE.equals(s.getContactType()) && (s.getExtension() != null)
							&& (s.getExtension().length() > 0))
					{
						int vruDelay = s.getVruDelay();

						vruDelay = vruDelay == 0 ? 2 : vruDelay;
						dest.setAddress((s.getValue() + StringUtils.repeat(",", vruDelay / 2) + s.getExtension()));

					}

					dest.setIsDefault(s.isDefault());
					dest.setIsActivated(true);

					return dest;
				}).collect(Collectors.toList());

				authenticationService.updateUserSecurityContactInformation(combinedDestinations,
					securityContactRequests.viewType);
			}
			else
			{
				throw new WrapperException("INVALID_DEFAULT_CONTACT", "Only One Security Contact Must be set to Default");
			}
		}
		else
		{
			throw new WrapperException("NO_SECURITY_CONTACT", "Atleast one Security Contact has to be set for the User");
		}
		resp.setResponseOK();
		return resp;
	}

	public Set<ChallengePoint> provideChallengePointServiceCodesFor_updatesSecurityContactInfo(
			@Valid @RequestBody @NotNull SecurityContactRequest securityContactRequests)
	{
		if(securityContactRequests.getViewType().equals(ViewTypeRequest.ViewType.ENROLL))
		{
			return Stream.of(ChallengePoint.NO_CHALLENGE).collect(Collectors.toSet());
		}
		return Stream.of(ChallengePoint.SELF_ADMIN).collect(Collectors.toSet());
	}

	@ApiOperation(value = "Sends the Activation code", notes = "Sends the Activation code by calling the Notification service")
	@RequestMapping(value = "/sendActivationCode", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	public StandardResponse<?> sendActivationCode(@Valid @RequestBody @NotNull List<SecurityContact> securityContacts)
			throws BadSession, ExceptionUserNotFound, Exception
	{

		final StandardResponse<?> resp = new StandardResponse<>();
		if (!securityContacts.isEmpty())
		{
			final List<Destination> combinedDestinations = securityContacts.stream().map(s -> {
				final Destination dest = new Destination(s.getValue(), s.getContactType());
				dest.setIsDefault(s.isDefault());
				return dest;
			}).collect(Collectors.toList());

			final boolean success = authenticationService.sendActivationCodeToDestinations(combinedDestinations);
			if (success)
			{
				resp.setResponseOK();
			}
		}

		return resp;
	}

	@ApiOperation(value = "Validate Activation code", notes = "Validates the Activation code against the one returned by the Notification service")
	@RequestMapping(value = "/validateActivationCode", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	@AllowEmulation
	public StandardResponse<?> validateActivationCode(@Valid @RequestBody @NotBlank String activationCode)
			throws BadSession, ExceptionUserNotFound, Exception
	{

		final StandardResponse<?> resp = new StandardResponse<>();

		final boolean success = authenticationService.validateActivationCode(activationCode.trim());
		if (success)
		{
			resp.setResponseOK();
		}
		else
		{
			throw new InvalidDataException("INVALID_CODE", "ACtivation Code is Expired or Invalid");
		}

		return resp;
	}

	@ApiOperation(value = "Update User First Time Login Completion", notes = "Update User First Time Login Completion Indicator")
	@RequestMapping(value = "/updateFirstTimeLoginStatus", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	public BasicResponse updateFirstTimeLoginCompletion() throws BadSession, RemoteException
	{
		final BasicResponse resp = new BasicResponse();
		authenticationService.updateUserFirstTimeLoginCompletionInfo();
		resp.setResponseOK("User First Time Login Completion Status Updated successfully");
		return resp;
	}

	@PublicApi
	@ApiOperation(value = "Sends the OTP code To Destination", notes = "Sends the Activation code by calling the Notification service")
	@PostMapping(value = "/sendOTPCode", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public StandardResponse<?> sendOneTimePassCode(@Valid @RequestBody @NotNull OneTimePasscodeRequest oneTimePasscodeRequest,
			HttpServletRequest httpRequest)
	{

		final StandardResponse<?> resp = new StandardResponse<>();
		if (oneTimePasscodeRequest != null)
		{
			final Destination dest = new Destination(oneTimePasscodeRequest.getValue(),
				oneTimePasscodeRequest.getContactType());

			final List<Destination> combinedDestinations = new ArrayList<>();
			combinedDestinations.add(dest);

			loadSessionAware(httpRequest);
			challengeManager.sendChallenge(oneTimePasscodeRequest.getContactType(), oneTimePasscodeRequest.getValue());
			resp.setResponseOK();
			//TODO: Code the logic to set the Sent count Refer OTPBean.sendOtpRequest() in bfs
			//Put in check for channel not being defined for user.One Time Passcode Delivery Channel settings have not been defined.  Please contact your Bank Administrator for further information.
		}

		return resp;
	}

	private void loadSessionAware(HttpServletRequest httpRequest)
	{
		String sessionId = cbeContextBeanLoader.getToken(httpRequest.getHeader(AUTHORIZATION));
		final Optional<LoginChallenge> dbRecord = loginChallengeRepository.findById(sessionId);
		if(dbRecord.isPresent())
		{
			//if dbRecord is present, it means the auth header contains a temp session id,
			// so we will get the real session id from the mapping table in the db.
			sessionId = dbRecord.get().getSessionId();
		}
		cbeContextBeanLoader.loadSessionAware(sessionId, httpRequest.getRequestURI());
	}
}
