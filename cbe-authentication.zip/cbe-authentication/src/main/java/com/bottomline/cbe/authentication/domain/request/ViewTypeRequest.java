package com.bottomline.cbe.authentication.domain.request;

import java.io.Serializable;

public class ViewTypeRequest  implements Serializable
{
	public enum ViewType {ENROLL, MAINTENANCE, CHALLENGE};
	
	public ViewType viewType;

	public ViewType getViewType()
	{
		return viewType;
	}

	public void setViewType(ViewType viewType)
	{
		this.viewType = viewType;
	}
	
}
