package com.bottomline.cbe.authentication.domain.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SessionTimeResponse implements Serializable {

	@JsonProperty("sessionTimeRemaining")
	private Long sessionTimeRemaining;
	
	@JsonProperty("inactivityWarningLeadTime")
	private Long inactivityWarningLeadTime;

	public Long getSessionTimeRemaining() {
		return sessionTimeRemaining;
	}

	public void setSessionTimeRemaining(Long sessionTimeRemaining) {
		this.sessionTimeRemaining = sessionTimeRemaining;
	}

	public Long getInactivityWarningLeadTime() {
		return inactivityWarningLeadTime;
	}

	public void setInactivityWarningLeadTime(Long inactivityWarningLeadTime) {
		this.inactivityWarningLeadTime = inactivityWarningLeadTime;
	}

	
}
