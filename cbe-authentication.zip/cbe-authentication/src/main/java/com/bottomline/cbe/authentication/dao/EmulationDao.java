package com.bottomline.cbe.authentication.dao;

import java.util.Map;

public interface EmulationDao {

    public Map<String, String> listEmulatableCustomers();
    public Map<String, String> listEmulatableUsers(final String customerId);
    public boolean isEmulatable(final String customerCode, final String userCode);
}
