package com.bottomline.cbe.authentication.jpa;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bottomline.cbe.authentication.jpa.entity.Users;
import com.bottomline.cbe.authentication.jpa.entity.UsersId;

/**
 * 
 * @author ravi.pulluri
 *
 */
@Repository
public interface UsersRepository extends JpaRepository<Users, UsersId>
{
	List<Users> findAllByIdUsercust(final String userCustomer);

	List<Users> findAllByIdUsercustAndUseractive(final String userCustomer, final int useractive);
}
