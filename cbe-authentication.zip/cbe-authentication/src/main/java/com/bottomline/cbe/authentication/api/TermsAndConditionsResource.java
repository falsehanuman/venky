package com.bottomline.cbe.authentication.api;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bottomline.cbe.authentication.MessageConstants;
import com.bottomline.cbe.authentication.bean.TermsAndConditions;
import com.bottomline.cbe.authentication.domain.request.TermsAndConditionsRequest;
import com.bottomline.cbe.authentication.domain.response.TermsConditionsResponse;
import com.bottomline.cbe.authentication.service.TermsAndConditionsService;
import com.bottomline.cbe.context.SessionAware;
import com.bottomline.cbe.exception.CBEBusinessException;
import com.bottomline.cbe.servicescore.domain.response.BasicResponse;
import com.bottomline.cbe.servicescore.domain.response.StandardResponse;
import com.magnetbanking.foundation.fraudcheck.util.FraudCheckRequestUtils;
import com.magnetbanking.foundation.logon.web.LogonUtils;
import com.magnetbanking.foundation.session.filter.ChallengeUtils;
import com.magnetbanking.foundation.session.iface.MagnetSessionOps;
import com.magnetbanking.foundation.terms.vo.TermsConditionsVO;
import com.magnetbanking.foundation.users.vo.UserVO;
import com.magnetbanking.util.BBCodeToHtml;
import com.magnetbanking.util.HtmlUtils;
import com.magnetbanking.util.exceptions.MagnetSecurityException;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/termsAndConditions")
public class TermsAndConditionsResource
{

	@Autowired
	SessionAware session;

	@Autowired
	MagnetSessionOps sessionBean;

	@Autowired
	TermsAndConditionsService termsAndConditionsService;

	@Autowired
	UsersResource userResource;
	
	@Autowired
	FraudCheckRequestUtils fraudCheckRequestUtils;

	@ApiOperation(value = "Email Terms And Conditions", notes = "Email Terms and Conditions for the User.")
	@RequestMapping(value = "/emailTsAndCs", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	public BasicResponse sendEmailTsAndCs(@Valid @RequestBody final TermsAndConditionsRequest request)
			throws MagnetSecurityException, CBEBusinessException, Exception
	{

		String message = "";
		UserVO userVo = userResource.getUserVO(session.getCustomerCode(), session.getUserCode());
		TermsAndConditions termsConditions = termsAndConditionsService.getTsAndCsById(request.getTermsConditionsId(), true);

		if (termsConditions == null)
		{
			throw new CBEBusinessException(MessageConstants.TERMS_CONDITIONS_NOT_FOUND,
					"Terms & Conditoins not found for the Lead Bank");
		}

		message = (HtmlUtils.isHtml(termsConditions.getTermsConditionsMessage())) ? termsConditions.getTermsConditionsMessage()
				: BBCodeToHtml.toRealHtml(termsConditions.getTermsConditionsMessage());

		termsAndConditionsService.sendEmailForTsAndCs(userVo, message);

		BasicResponse resp = new BasicResponse();
		String userMessage = "Email with Terms and Conditions sent successfully";
		resp.setResponseOK(userMessage, "Email with Terms and Conditions sent successfully");
		return resp;
	}

	@PostMapping(value = "/acceptTsAndCs", produces = "application/json", consumes = "application/json")
	@ApiOperation(value = "Accepts Terms And Conditions", notes = "Records the Acceptance of Terms And Conditions for the User.")
	public BasicResponse acceptTsAndCs(@Valid @RequestBody final TermsAndConditionsRequest request)
	{

		TermsConditionsVO termsConditionsVO = new TermsConditionsVO();
		termsConditionsVO.setTerms_cond_id(request.getTermsConditionsId());
		termsConditionsVO.setTerms_cond_name(request.getTermsConditionsName());
		termsAndConditionsService.userAcceptedTerms(termsConditionsVO);

		 /* fraudCheckRequestUtils.populateAuthAndSendLoginEventIfFCEnabled(LogonUtils.LogonStatus.SUCCESSFUL,
			  "Success", ChallengeUtils.ChallengeReason.SYSTEM_OR_ADMIN_FORCED_RESET, session.getSessionVo());*/
		BasicResponse resp = new BasicResponse();
		resp.setResponseOK("Terms and Conditions Accepted");
		return resp;
	}

	@PostMapping(value = "/declineTsAndCs", produces = "application/json", consumes = "application/json")
	@ApiOperation(value = "Declines Terms And Conditions", notes = "Records the user's Declination of Terms And Conditions and Logs off the user.")
	public BasicResponse declineTsAndCs(@Valid @RequestBody final TermsAndConditionsRequest request)
			throws CBEBusinessException, Exception
	{

		TermsConditionsVO termsConditionsVO = new TermsConditionsVO();
		termsConditionsVO.setTerms_cond_id(request.getTermsConditionsId());
		termsConditionsVO.setTerms_cond_name(request.getTermsConditionsName());
		termsAndConditionsService.userDeclinedTerms(termsConditionsVO);

		  /*fraudCheckRequestUtils.populateAuthAndSendLoginEventIfFCEnabled(LogonUtils.LogonStatus.FAILED_AUTHENTICATION,
			  "Success", ChallengeUtils.ChallengeReason.SYSTEM_OR_ADMIN_FORCED_RESET, session.getSessionVo());*/
		  
		sessionBean.deactivate(session.getSessionId());

		BasicResponse resp = new BasicResponse();
		resp.setResponseOK("Terms and Conditions Declined");
		return resp;
	}

	@PostMapping(value = "/getTsAndCs", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retrieves Terms And Conditions", notes = "Retrieves all the valid and eligible terms And Conditions for the User.")
	public StandardResponse<TermsConditionsResponse> getTcsAndCs() throws CBEBusinessException, Exception
	{

		StandardResponse<TermsConditionsResponse> resp = new StandardResponse<TermsConditionsResponse>();
		TermsConditionsResponse termsConditions = new TermsConditionsResponse();

		List<TermsAndConditions> termsConditionsList = termsAndConditionsService.getTcsAndCs();
		termsConditions.setTermsAndConditions(termsConditionsList);
		resp.setData(termsConditions);
		resp.setResponseOK();
		return resp;
	}
}
