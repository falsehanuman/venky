package com.bottomline.cbe.authentication.service;

import com.bottomline.cbe.authentication.domain.response.TrusteerSysOptionsResponse;

public interface SecurityService
{

	public TrusteerSysOptionsResponse getTrusteerSysOptions();
}
