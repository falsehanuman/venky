package com.bottomline.cbe.authentication.api;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bottomline.cbe.authentication.MessageConstants;
import com.bottomline.cbe.authentication.domain.request.ResetPasswordRequest;
import com.bottomline.cbe.authentication.domain.request.ResetPasswordResponse;
import com.bottomline.cbe.authentication.domain.request.UserResourceRequest;
import com.bottomline.cbe.authentication.domain.response.UserResourceResponse;
import com.bottomline.cbe.authentication.service.AuthenticationService;
import com.bottomline.cbe.common.StringFunctions;
import com.bottomline.cbe.exception.CBEBusinessException;
import com.bottomline.cbe.servicescore.annotation.AllowedOnly;
import com.bottomline.cbe.servicescore.annotation.PublicApi;
import com.bottomline.cbe.servicescore.domain.response.StandardResponse;
import com.bottomline.foundation.session.vo.SessionVO;
import com.magnetbanking.foundation.fraudcheck.ga.enums.GALogonStatusEnum;
import com.magnetbanking.foundation.fraudcheck.ga.enums.GAPasswordChangeReason;
import com.magnetbanking.foundation.fraudcheck.util.FraudCheckRequestUtils;
import com.magnetbanking.foundation.leadbank.dao.LeadbankDAO;
import com.magnetbanking.foundation.leadbank.vo.LeadbankVO;
import com.magnetbanking.foundation.logon.web.LogonUtils;
import com.magnetbanking.foundation.services.iface.Service;
import com.magnetbanking.foundation.services.vo.ServiceVO;
import com.magnetbanking.foundation.session.filter.ChallengeUtils;
import com.magnetbanking.foundation.session.iface.UserLockedOut;
import com.magnetbanking.foundation.users.iface.InvalidSecurityAnswers;
import com.magnetbanking.foundation.users.vo.UserInfoVO;
import com.magnetbanking.foundation.users.vo.UserVO;
import com.magnetbanking.ibs.ecomAPIPackage.ExceptionUserNotFound;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("public/user")
public class UsersResource
{

	@Autowired
	AuthenticationService authenticationService;
	@Autowired
	FraudCheckRequestUtils fraudCheckRequestUtils;
	@Autowired
	LeadbankDAO leadbbankDAO;

	@RequestMapping(value = "/getSecurityQuestions", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	@ApiOperation(value = "Retrieves Security Question", notes = "Retrieves the Security Questions set for the User.")
	//@AllowedOnly(anyCustomerUser = true)
	@PublicApi
	public StandardResponse<UserResourceResponse> getUserSecurityQuestion(@Valid @RequestBody final UserResourceRequest request,
			HttpServletRequest httpRequest, HttpServletResponse response) throws Exception
	{

		validateUserAndCustomerIds(request.getCustCode(), request.getUserCode());

		StandardResponse<UserResourceResponse> resp = new StandardResponse<UserResourceResponse>();

		UserVO userVo = getUserVO(request.getCustCode(), request.getUserCode());

		validateUserIsEnabled(userVo, request.getCustCode());
		validateUserIsNotInactive(userVo, request.getCustCode());
		validateUserIsNotAdminOrSecurityLocked(userVo);
		validateUserCompletedFirstTimeLogin(userVo);

		UserInfoVO userInfoVO = authenticationService.getUserSecurityInformation(userVo.getCustId(), userVo.getId());
		validateSecurityQuestions(userVo, userInfoVO);

		UserResourceResponse userResourceResponse = new UserResourceResponse();
		userResourceResponse.setSecurityQuestion1(authenticationService.getSecurityQuestion(userInfoVO.getQuestion1Id()));
		userResourceResponse.setSecurityQuestion2(authenticationService.getSecurityQuestion(userInfoVO.getQuestion2Id()));
		userResourceResponse.setSecurityQuestion3(authenticationService.getSecurityQuestion(userInfoVO.getQuestion3Id()));

		resp.setData(userResourceResponse);
		resp.setResponseOK();
		return resp;

	}

	@RequestMapping(value = "/resetPassword", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Reset Password", notes = "Validates the User Security Question's Answer and Emails the newly generated Temporary Password to the User.")
	//@AllowedOnly(anyCustomerUser = true)
	@PublicApi
	public StandardResponse<ResetPasswordResponse> resetPassword(@Valid @RequestBody ResetPasswordRequest request)
			throws Exception
	{

		validateUserAndCustomerIds(request.getCustCode(), request.getUserCode());
		UserVO userVo = getUserVO(request.getCustCode(), request.getUserCode());
		validateUserIsEnabled(userVo, request.getCustCode());
		validateUserIsNotInactive(userVo, request.getCustCode());
		validateUserIsNotAdminOrSecurityLocked(userVo);
		validateUserCompletedFirstTimeLogin(userVo);
		UserInfoVO userInfo = authenticationService.getUserSecurityInformation(userVo.getCustId(), userVo.getId());
		validateSecurityQuestions(userVo, userInfo);
		boolean answersCorrect = authenticationService.checkSecurityAnswers(userInfo, request.getAnswer1(), request.getAnswer2(),
			request.getAnswer3());
		
		//Below code is added for FruadMap events
		LeadbankVO leadBankVO = leadbbankDAO.getLeadbankByCustCode(request.getCustCode());
		ServiceVO serviceVO = new ServiceVO();
		serviceVO.setCode(Service.LOGIN.getCode());
		SessionVO sessionVO = new SessionVO("", request.getCustCode(), Integer.valueOf(userVo.getCustId().intValue()), userVo.getCode(), Integer.valueOf(userVo.getId().intValue()),
				null, leadBankVO.getId().intValue(), new Date(), new Date(), new Long(0).longValue(), new Long(0).longValue(), serviceVO, userVo.isAdmin());
		
		if (!answersCorrect)
		{
			UserVO updatedUser = authenticationService.invalidSecurityAnswerAttempt(userInfo);
			if (updatedUser.getSecurityQuestionLock() == 1)
			{
				fraudCheckRequestUtils.populateAuthAndSendLoginEventIfFCEnabled(LogonUtils.LogonStatus.LOCKED_OUT,
					GALogonStatusEnum.FAILED_AUTHENTICATION.getValidApiValue(), ChallengeUtils.ChallengeReason.SYSTEM_OR_ADMIN_FORCED_RESET, sessionVO);
				
				throw new UserLockedOut(MessageConstants.EXCESS_INVALID_ATTEMPTS,
						"User locked out because of exceeding the security answers attempts");
			}
			else
			{
				fraudCheckRequestUtils.populateAuthAndSendLoginEventIfFCEnabled(LogonUtils.LogonStatus.FAILED_AUTHENTICATION,
					GALogonStatusEnum.FAILED_AUTHENTICATION.getValidApiValue(), ChallengeUtils.ChallengeReason.SYSTEM_OR_ADMIN_FORCED_RESET, sessionVO);
				
				throw new InvalidSecurityAnswers(MessageConstants.SECURITY_QUESTION_ANSWERS_INVALID,
						"Security answers were incorrect");
			}
		}
		else
		{
			authenticationService.doTemporaryPasswordReset(userVo, userInfo);
			StandardResponse<ResetPasswordResponse> retVal = new StandardResponse<>();
			ResetPasswordResponse resetPasswordResponse = new ResetPasswordResponse();
			resetPasswordResponse.setEmailId(StringFunctions.maskEmail(userVo.getEmail()));
			resetPasswordResponse.setPhoneNumber(StringFunctions.maskPhone(userVo.getDataPhone()));
			retVal.setData(resetPasswordResponse);
			retVal.setResponseOK("Temporary password issued");
			
			
			fraudCheckRequestUtils.fraudCheckPasswordChange(GAPasswordChangeReason.FORGOTTEN.getApiValue(), sessionVO);
			
			return retVal;
		}

	}

	void validateUserAndCustomerIds(String custId, String userId)
	{
		if (StringUtils.isBlank(custId) || StringUtils.isBlank(userId))
			throw new CBEBusinessException(MessageConstants.ID_MISSING, "Customer ID or User ID is Missing in request");
	}

	UserVO getUserVO(String custId, String userId)
	{
		try
		{
			return authenticationService.getUserInformation(custId, userId);
		}
		catch (ExceptionUserNotFound e)
		{

			throw new CBEBusinessException(MessageConstants.ID_MISMATCH, "Customer ID And User ID Combination is wrong");
		}
	}

	void validateUserCompletedFirstTimeLogin(UserVO userVo)
	{

		if (userVo.getFirstTimeLoginComplete() == 0)
		{
			throw new CBEBusinessException(MessageConstants.NO_SECURITY_QUESTIONS,
					"Security question  is not set because first Time login is not complete");
		}
	}

	void validateSecurityQuestions(UserVO userVO, UserInfoVO userInfoVO)
	{
		if (null == userInfoVO)
		{
			throw new CBEBusinessException(MessageConstants.NO_SECURITY_QUESTIONS, "Security question  is not set");
		}
		if (StringUtils.isBlank(userVO.getEmail()))
		{
			throw new CBEBusinessException(MessageConstants.NO_EMAIL_ID, "Email is not set");
		}
	}

	void validateUserIsEnabled(UserVO userVo, String custCode)
	{

		if (!authenticationService.isUserEnabled(userVo) || !authenticationService.isCBEUser(custCode))
		{
			throw new CBEBusinessException(MessageConstants.USER_NOT_ENABLED, "User is not enabled");
		}
	}

	private void validateUserIsNotAdminOrSecurityLocked(UserVO userVo)
	{

		if (userVo.getBankAdminLock() == 1 || userVo.getCustAdminLock() == 1)
		{
			throw new CBEBusinessException(MessageConstants.USER_ADMIN_lOCKED,
					"Cannot use Reset Password as the User is Admin Locked");
		}
		if (userVo.getSecurityQuestionLock() == 1)
		{
			throw new CBEBusinessException(MessageConstants.EXCESS_INVALID_SECURITY_QUESTION_ANSWERS_ATTEMPTS,
					"Cannot use Reset Password as the user has exceed the permissible attempts to answer the Security Question");
		}
	}

	private void validateUserIsNotInactive(UserVO userVO, String custCode)
	{
		if (authenticationService.isUserInactive(userVO, custCode))
		{

			throw new CBEBusinessException(MessageConstants.INACTIVE_USER, "Inactive Users");
		}
	}

}
