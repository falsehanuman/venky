package com.bottomline.cbe.authentication.domain.response;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;

/**
 * 
 * @author ravi.pulluri
 *
 * @param <R>
 */
@Component
@Scope(value = "request", proxyMode = ScopedProxyMode.TARGET_CLASS)
public class AuthenticationCommonResponse<R> {

	private R request;

	public R getRequest() {
		return request;
	}

	public void setRequest(R request) {
		this.request = request;
	}
}
