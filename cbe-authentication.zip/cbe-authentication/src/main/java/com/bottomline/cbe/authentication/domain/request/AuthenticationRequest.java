package com.bottomline.cbe.authentication.domain.request;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.bottomline.cbe.servicescore.validation.constratints.NotBlank;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * 
 * @author Ravi Pulluri
 * 
 */
public class AuthenticationRequest implements Serializable
{

	private static final long serialVersionUID = 1L;

	@JsonProperty("customerCode")
	@NotBlank(message = "AUTH0017")
	private String custCode;

	@JsonProperty("userCode")
	@NotBlank(message = "AUTH0017")
	private String userCode;

	@JsonProperty("userPassword")
	@NotBlank
	private String userPwd;

	@JsonProperty("redirectToken")
	private String redirectToken;

	public AuthenticationRequest() {
	}

	public AuthenticationRequest(String custCode, String userCode, String userPwd) {
		this.custCode = custCode;
		this.userCode = userCode;
		this.userPwd = userPwd;
	}

	public AuthenticationRequest(String custCode, String userCode, String userPwd, String redirectToken) {
		this.custCode = custCode;
		this.userCode = userCode;
		this.userPwd = userPwd;
		this.redirectToken = redirectToken;
	}

	public String getUserCode()
	{
		return userCode;
	}

	public void setUserCode(String userCode)
	{
		this.userCode = userCode;
	}

	public String getCustCode()
	{
		return custCode;
	}

	public void setCustCode(String custCode)
	{
		this.custCode = custCode;
	}

	public String getUserPwd()
	{
		return userPwd;
	}

	public void setUserPwd(String userPwd)
	{
		this.userPwd = userPwd;
	}

	public String getRedirectToken() {
		return redirectToken;
	}

	public void setRedirectToken(String redirectToken) {
		this.redirectToken = redirectToken;
	}

	@Override
	public String toString()
	{
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}
}
