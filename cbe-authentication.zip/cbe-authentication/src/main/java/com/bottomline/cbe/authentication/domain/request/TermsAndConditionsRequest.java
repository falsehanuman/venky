package com.bottomline.cbe.authentication.domain.request;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

public class TermsAndConditionsRequest implements Serializable
{

	private static final long serialVersionUID = 1L;

	@JsonProperty("termsConditionsId")
	@NotNull(message = "TERMS_AND_CONDITIONS_ID_MISSING")
	private Integer termsConditionsId;

	@JsonProperty("termsConditionsName")
	private String termsConditionsName;

	public String getTermsConditionsName()
	{
		return termsConditionsName;
	}

	public void setTermsConditionsName(String termsConditionsName)
	{
		this.termsConditionsName = termsConditionsName;
	}

	public Integer getTermsConditionsId()
	{
		return termsConditionsId;
	}

	public void setTermsConditionsId(Integer termsConditionsId)
	{
		this.termsConditionsId = termsConditionsId;
	}
	

}
