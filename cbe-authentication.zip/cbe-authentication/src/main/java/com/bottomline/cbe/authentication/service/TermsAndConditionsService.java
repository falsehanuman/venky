package com.bottomline.cbe.authentication.service;

import java.util.List;

import com.bottomline.cbe.authentication.bean.TermsAndConditions;
import com.bottomline.cbe.authentication.domain.request.TermsAndConditionsRequest;
import com.bottomline.cbe.exception.CBEBusinessException;
import com.magnetbanking.foundation.session.iface.MagnetSession;
import com.magnetbanking.foundation.terms.vo.TermsConditionsVO;
import com.magnetbanking.foundation.users.vo.UserVO;
import com.magnetbanking.util.exceptions.MagnetSecurityException;

public interface TermsAndConditionsService {

	public List<TermsAndConditions> getTcsAndCs() throws CBEBusinessException, Exception;
	
	public void sendEmailForTsAndCs(UserVO userVO, String tersmAndConditions) throws CBEBusinessException, Exception;
	
	public TermsAndConditions getTsAndCsById(int termsCondsId, boolean includeAudience) throws MagnetSecurityException, CBEBusinessException, Exception;
	
	public void userAcceptedTerms(TermsConditionsVO termsConditionsVO);
	
	public void userDeclinedTerms(TermsConditionsVO termsConditionsVO) throws MagnetSecurityException, Exception;
	
	
}
