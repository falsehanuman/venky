package com.bottomline.cbe.authentication.domain.request;

import javax.validation.Valid;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.bottomline.cbe.servicescore.validation.constratints.NotBlank;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @author ravi.pulluri
 *
 */
@JsonPropertyOrder(alphabetic = true)
@Valid
@ApiModel(value = "EmulationReq", description = "To retrieve list of customers or users to emulate")
public class EmulationReq
{
	@ApiModelProperty(required = true)
	@JsonProperty("customerCode")
	@NotBlank(message = "EMULATION.VALIDATION_CUSTOMER_CODE")
	private String customerCode;

	@ApiModelProperty(required = true, notes = "User code is mandatory to start emulation session")
	@JsonProperty("userCode")
	private String userCode;

	public String getCustomerCode()
	{
		return customerCode;
	}

	public void setCustomerCode(String customerCode)
	{
		this.customerCode = customerCode;
	}

	public String getUserCode()
	{
		return userCode;
	}

	public void setUserCode(String userCode)
	{
		this.userCode = userCode;
	}

	@Override
	public String toString()
	{
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

}
