package com.bottomline.cbe.authentication.domain.request;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.bottomline.cbe.servicescore.validation.constratints.NotBlank;
import com.fasterxml.jackson.annotation.JsonProperty;

public class UserResourceRequest implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonProperty("customerCode")
	@NotBlank(message = "AUTH0017")
	private String custCode;

	@JsonProperty("userCode")
	@NotBlank(message = "AUTH0017")
	private String userCode;

	public String getCustCode() {
		return custCode;
	}

	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}
}
