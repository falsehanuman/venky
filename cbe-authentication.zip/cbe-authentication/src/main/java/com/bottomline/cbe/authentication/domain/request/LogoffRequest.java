package com.bottomline.cbe.authentication.domain.request;

import com.fasterxml.jackson.annotation.JsonProperty;

public class LogoffRequest
{

	@JsonProperty("isSessionExpired")
	private boolean sessionExpired;

	public boolean isSessionExpired()
	{
		return sessionExpired;
	}

	public void setSessionExpired(boolean sessionExpired)
	{
		this.sessionExpired = sessionExpired;
	}
	
}
