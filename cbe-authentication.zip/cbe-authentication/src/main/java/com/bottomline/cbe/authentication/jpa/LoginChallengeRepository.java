package com.bottomline.cbe.authentication.jpa;

import com.bottomline.cbe.authentication.jpa.entity.LoginChallenge;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LoginChallengeRepository extends JpaRepository<LoginChallenge, String>
{
}
