package com.bottomline.cbe.authentication.domain.response;

import java.util.List;

import com.bottomline.cbe.authentication.bean.TermsAndConditions;
import com.fasterxml.jackson.annotation.JsonProperty;

public class TermsConditionsResponse {

	@JsonProperty("termsAndCondtions")
	List<TermsAndConditions> termsAndConditions;

	public List<TermsAndConditions> getTermsAndConditions() {
		return termsAndConditions;
	}

	public void setTermsAndConditions(List<TermsAndConditions> termsAndConditions) {
		this.termsAndConditions = termsAndConditions;
	}

}
