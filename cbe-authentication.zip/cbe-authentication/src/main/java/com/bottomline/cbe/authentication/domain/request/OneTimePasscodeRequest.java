package com.bottomline.cbe.authentication.domain.request;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import com.magnetbanking.foundation.challengemanager.providers.mfa2.vo.Destination.Protocol;

public class OneTimePasscodeRequest implements Serializable
{
	@NotNull
	private Protocol contactType;
	@NotNull
	private String value;

	public Protocol getContactType()
	{
		return contactType;
	}

	public void setContactType(Protocol contactType)
	{
		this.contactType = contactType;
	}

	public String getValue()
	{
		return value;
	}

	public void setValue(String value)
	{
		this.value = value;
	}


}
