package com.bottomline.cbe.authentication.domain.response;

import com.fasterxml.jackson.annotation.JsonProperty;

public class TrusteerSysOptionsResponse
{

	private static final long serialVersionUID = 1L;

	@JsonProperty("snippetId")
	private String snippetId;

	@JsonProperty("pinpointEnabled")
	private Boolean pinpointEnabled;
	
	@JsonProperty("rapportEnabled")
	private String rapportEnabled;
	
	@JsonProperty("pinPointURL")
	private String pinPointURL;
	
	@JsonProperty("rapportServer")
	private String rapportServer;
	
	@JsonProperty("sharedKey")
	private String sharedKey;
	
	@JsonProperty("tenantId")
	private String tenantId;

	@JsonProperty("message")
	private String message;

	@JsonProperty("defaultTag")
	private String defaultTag;

	@JsonProperty("callBack")
	private String callBackMethod;
	
	@JsonProperty("globalFunctionName")
	private String globalFunctionName;

	public String getSnippetId()
	{
		return snippetId;
	}

	public void setSnippetId(String snippetId)
	{
		this.snippetId = snippetId;
	}

	public String getCallBackMethod()
	{
		return callBackMethod;
	}

	public void setCallBackMethod(String callBackMethod)
	{
		this.callBackMethod = callBackMethod;
	}

	public String getPinPointURL()
	{
		return pinPointURL;
	}

	public void setPinPointURL(String pinPointURL)
	{
		this.pinPointURL = pinPointURL;
	}
	
	public String getRapportServer()
	{
		return rapportServer;
	}

	public void setRapportServer(String rapportServer)
	{
		this.rapportServer = rapportServer;
	}

	public String getDefaultTag()
	{
		return defaultTag;
	}

	public void setDefaultTag(String defaultTag)
	{
		this.defaultTag = defaultTag;
	}

	public Boolean getPinpointEnabled()
	{
		return pinpointEnabled;
	}

	public void setPinpointEnabled(Boolean pinpointEnabled)
	{
		this.pinpointEnabled = pinpointEnabled;
	}

	public String getRapportEnabled()
	{
		return rapportEnabled;
	}

	public void setRapportEnabled(String rapportEnabled)
	{
		this.rapportEnabled = rapportEnabled;
	}
	
	public String getTenantId()
	{
		return tenantId;
	}

	public void setTenantId(String tenantId)
	{
		this.tenantId = tenantId;
	}

	public String getMessage()
	{
		return message;
	}

	public void setMessage(String message)
	{
		this.message = message;
	}

	public String getSharedKey()
	{
		return sharedKey;
	}

	public void setSharedKey(String sharedKey)
	{
		this.sharedKey = sharedKey;
	}

	public String getGlobalFunctionName()
	{
		return globalFunctionName;
	}

	public void setGlobalFunctionName(String globalFunctionName)
	{
		this.globalFunctionName = globalFunctionName;
	}

	public static long getSerialversionuid()
	{
		return serialVersionUID;
	}
	
	
}
