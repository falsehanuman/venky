package com.bottomline.cbe.authentication.domain.response;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * This class is used to carry JSON response for PasswordComplexityRequirement API calls
 * @author Gangadhar.Bolikonda
 *
 */

@JsonInclude(value = Include.NON_NULL)
public class PasswordComplexityResponse implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonProperty("leadBankCode")
	private String lbCode;

	@JsonProperty("customerCode")
	private String custCode;

	@JsonProperty("userCode")
	private String userCode;

	@JsonProperty("minPasswordLength")
	private int minPasswordLength;

	@JsonProperty("maxCustPasswordLength")
	private int maxCustPasswordLength;
	
	@JsonProperty("maxUserPasswordLength")
	private int maxUserPasswordLength;

	@JsonProperty("passwordPattern")
	private String passwordPattern;

	@JsonProperty("passwordPatternDescription")
	private String passwordPatternDescription;
	
	@JsonProperty("passwordExclusions")
	private List<String> passwordInclusions;

	@JsonProperty("passwordHistoryLength")
	private int passwordHistoryLength;
	
	@JsonProperty("passwordExpireDays")
	private int passwordExpireDays;
	
	@JsonProperty("passwordExpireWarn")
	private int passwordExpireWarn;
	

	public String getLbCode() {
		return lbCode;
	}

	public void setLbCode(String lbCode) {
		this.lbCode = lbCode;
	}

	public String getCustCode() {
		return custCode;
	}

	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public int getMinPasswordLength() {
		return minPasswordLength;
	}

	public void setMinPasswordLength(int minPasswordLength) {
		this.minPasswordLength = minPasswordLength;
	}

	public int getMaxCustPasswordLength() {
		return maxCustPasswordLength;
	}

	public void setMaxCustPasswordLength(int maxCustPasswordLength) {
		this.maxCustPasswordLength = maxCustPasswordLength;
	}

	public int getMaxUserPasswordLength() {
		return maxUserPasswordLength;
	}

	public void setMaxUserPasswordLength(int maxUserPasswordLength) {
		this.maxUserPasswordLength = maxUserPasswordLength;
	}

	public String getPasswordPattern() {
		return passwordPattern;
	}

	public void setPasswordPattern(String passwordPattern) {
		this.passwordPattern = passwordPattern;
	}

	public String getPasswordPatternDescription() {
		return passwordPatternDescription;
	}

	public void setPasswordPatternDescription(String passwordPatternDescription) {
		this.passwordPatternDescription = passwordPatternDescription;
	}

	public List<String> getPasswordInclusions() {
		return passwordInclusions;
	}

	public void setPasswordInclusions(List<String> passwordInclusions) {
		this.passwordInclusions = passwordInclusions;
	}

	public int getPasswordHistoryLength() {
		return passwordHistoryLength;
	}

	public void setPasswordHistoryLength(int passwordHistoryLength) {
		this.passwordHistoryLength = passwordHistoryLength;
	}

	public int getPasswordExpireDays() {
		return passwordExpireDays;
	}

	public void setPasswordExpireDays(int passwordExpireDays) {
		this.passwordExpireDays = passwordExpireDays;
	}

	public int getPasswordExpireWarn() {
		return passwordExpireWarn;
	}

	public void setPasswordExpireWarn(int passwordExpireWarn) {
		this.passwordExpireWarn = passwordExpireWarn;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

}
