package com.bottomline.cbe.authentication.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.ListIterator;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bottomline.cbe.authentication.bean.SecurityQuestion;
import com.bottomline.cbe.authentication.domain.request.ViewTypeRequest;
import com.bottomline.cbe.authentication.domain.request.ViewTypeRequest.ViewType;
import com.bottomline.cbe.authentication.domain.response.AuthenticationResponse;
import com.bottomline.cbe.authentication.domain.response.UserInformationResponse;
import com.bottomline.cbe.authentication.service.AuthenticationService;
import com.bottomline.cbe.context.SessionAware;
import com.bottomline.cbe.otp.domain.MfaCode;
import com.bottomline.cbe.otp.domain.MfaCodePK;
import com.bottomline.cbe.otp.persistence.MfaCodeDao;
import com.bottomline.foundation.session.vo.SessionVO;
import com.magnetbanking.foundation.calendar.dao.CalendarDAO;
import com.magnetbanking.foundation.challengemanager.bo.ChallengeManagerBo;
import com.magnetbanking.foundation.challengemanager.providers.mfa2.bo.NSClientBo;
import com.magnetbanking.foundation.challengemanager.providers.mfa2.vo.Destination;
import com.magnetbanking.foundation.challengemanager.providers.mfa2.vo.DestinationWebWrapper;
import com.magnetbanking.foundation.challengemanager.providers.mfa2.vo.MFA2CallResponse;
import com.magnetbanking.foundation.challengemanager.providers.mfa2.web.WebHelper;
import com.magnetbanking.foundation.challengemanager.vo.AuthSystemType;
import com.magnetbanking.foundation.customers.dao.CustomerDAO;
import com.magnetbanking.foundation.customers.vo.CustomerVO;
import com.magnetbanking.foundation.dichallenge.util.DIChallengeUtils;
import com.magnetbanking.foundation.infrastructure.option.iface.OptionConstants;
import com.magnetbanking.foundation.infrastructure.option.impl.OptionManager;
import com.magnetbanking.foundation.infrastructure.option.vo.OptionVO;
import com.magnetbanking.foundation.leadbank.dao.LeadbankDAO;
import com.magnetbanking.foundation.leadbank.vo.LeadbankVO;
import com.magnetbanking.foundation.session.dao.PasswordDAO;
import com.magnetbanking.foundation.session.iface.MagnetSession;
import com.magnetbanking.foundation.session.iface.MagnetSessionOps;
import com.magnetbanking.foundation.session.vo.LoginInfoVO;
import com.magnetbanking.foundation.session.vo.LoginRequestContextVO;
import com.magnetbanking.foundation.terms.bo.TermsBo;
import com.magnetbanking.foundation.terms.vo.TermsConditionsVO;
import com.magnetbanking.foundation.users.dao.UserDAO;
import com.magnetbanking.foundation.users.iface.UserOps;
import com.magnetbanking.foundation.users.vo.SecurityQuestionVO;
import com.magnetbanking.foundation.users.vo.UserInfoVO;
import com.magnetbanking.foundation.users.vo.UserVO;
import com.magnetbanking.ibs.ecomAPIPackage.ExceptionUserNotFound;
import com.magnetbanking.util.MibsUtils;
import com.magnetbanking.util.date.CalendarUtils;
import com.magnetbanking.util.exceptions.DataAccessException;
import com.magnetbanking.util.exceptions.InvalidDataException;
import com.magnetbanking.util.exceptions.NoSuchVOException;
import com.magnetbanking.util.exceptions.WrapperException;
import com.magnetbanking.util.mail.Email;
import com.magnetbanking.util.mail.MimeTypes;

@Service
public class AuthenticationServiceImpl implements AuthenticationService
{

	@Autowired
	MagnetSessionOps sessionOps;

	@Autowired
	TermsBo termsBo;

	@Autowired
	UserOps userOps;

	@Autowired
	SessionAware session;

	@Autowired
	UserDAO userDAO;

	@Autowired
	NSClientBo nsClient;

	@Autowired
	ChallengeManagerBo cmProxy;

	@Autowired
	MfaCodeDao mfaCodeDao;

	@Autowired
	DIChallengeUtils diChallengeUtils;

	@Autowired
	LeadbankDAO leadbankDAO;

	private static final String DEVICE_TOKENS = "DEVICE-TOKENS";

	@Override
	public AuthenticationResponse login(String customerCode, String userCode, String userPassword,
			LoginRequestContextVO logingReqContext, HttpServletRequest httpRequest) throws Exception
	{

		MagnetSession magnetSession = null;
		magnetSession = sessionOps.login(customerCode, userCode, userPassword, logingReqContext);
		final AuthenticationResponse authResponse = new AuthenticationResponse();

		final SessionVO sessionVo = magnetSession.getSessionVo();
		final LoginInfoVO loginInfoVO = magnetSession.getLoginInfo();
		populateBasicInfo(authResponse, sessionVo, loginInfoVO);

		if ((sessionVo != null) && !sessionVo.isBankUser())
		{
			populateAdditinalInfo(httpRequest, magnetSession, authResponse, sessionVo, loginInfoVO);
		}

		return authResponse;
	}

	private void populateAdditinalInfo(HttpServletRequest httpRequest, MagnetSession magnetSession,
			final AuthenticationResponse authResponse, final SessionVO sessionVo, final LoginInfoVO loginInfoVO) throws Exception
	{
		if (sessionVo != null)
		{

			if (loginInfoVO.getIsFirstLogin())
			{
				authResponse.setDeviceInfoAvailable(false);
				authResponse.setDeviceInfoEnabled(true);
			}
			else
			{
				//			authResponse.setDeviceInfoAvailable(diChallengeUtils.isValidDeviceToken(httpRequest, sessionVo));
				if (OptionManager.getOption(new Long(OptionConstants.DI_CHALLENGE_ENABLED), sessionVo.getLbId().longValue())
						.getIntValue() == 0)
				{
					authResponse.setDeviceInfoAvailable(true);
					authResponse.setDeviceInfoEnabled(false);

				}
				else
				{
					authResponse
					.setDeviceInfoAvailable(diChallengeUtils.isValidDeviceToken(httpRequest.getHeader(DEVICE_TOKENS), sessionVo));
					authResponse.setDeviceInfoEnabled(true);
				}
			}
			final Collection<TermsConditionsVO> usersTerms = getTermsForCorpUser(sessionVo);

			if ((usersTerms != null) && !usersTerms.isEmpty())
			{
				authResponse.setHasTermsAndConditions(true);
			}

			//			final LeadbankVO bank = leadbankDAO.getLeadbank(sessionVo.getLbCode());
			//			if (nsClient.isMFA2Enabled(bank, magnetSession.getSessionVo()))
			//			{
			//				authResponse.setMfaEnabled(true);
			//
			//				final MFA2CallResponse nsResponse = getDestinations(magnetSession.getSessionVo());
			//				if (nsResponse.isSuccess() && (nsResponse.getDestinations() != null) && !nsResponse.getDestinations().isEmpty())
			//				{
			//					authResponse.setSecurityContactRequired(false);
			//				}
			//				else
			//				{
			//					authResponse.setSecurityContactRequired(true);
			//				}
			//			}

			if(loginInfoVO!=null){
				authResponse.setMfaEnabled(loginInfoVO.isMfaEnabled());
				authResponse.setSecurityContactRequired(loginInfoVO.isSecurityContactRequired());
				authResponse.setVoiceEnabled(loginInfoVO.isVoiceEnabled());
			}


		}

		if (loginInfoVO != null)
		{
			authResponse.setChangePassword(loginInfoVO.getMustChangePassword());
			authResponse.setFirstLogin(loginInfoVO.getIsFirstLogin());
			authResponse.setShowPasswdExpWarning(loginInfoVO.getShowPswdExpirationWarning());
			authResponse.setSecAnsNeeded(loginInfoVO.getIsSecAnswersNeeded());
		}
	}



	private void populateBasicInfo(final AuthenticationResponse authResponse, final SessionVO sessionVo,
			final LoginInfoVO loginInfoVO)
	{
		if (sessionVo != null)
		{
			authResponse.setAuthenticationId(sessionVo.getId());
			authResponse.setUserCode(sessionVo.getUserCode());
			authResponse.setCustCode(sessionVo.getCustCode());
			authResponse.setBankUser(sessionVo.isBankUser());

			if (loginInfoVO.getLastloginTime() != null)
			{
				authResponse.setLastloginTime(loginInfoVO.getLastloginTime());
			}
			authResponse.setUserName(loginInfoVO.getUserName());
			final UserInformationResponse userInfo = new UserInformationResponse();
			userInfo.setAddress1(loginInfoVO.getAddress1());
			userInfo.setAddress2(loginInfoVO.getAddress2());
			userInfo.setCity(loginInfoVO.getCity());
			userInfo.setState(loginInfoVO.getState());
			userInfo.setPostalCode(loginInfoVO.getZip());
			userInfo.setEmail(loginInfoVO.getEmail());
			userInfo.setVoicePhone(loginInfoVO.getVoicePhone());
			userInfo.setFaxNumber(loginInfoVO.getFaxPhone());
			authResponse.setUserInformation(userInfo);
		}
	}

	@Override
	public MagnetSession findByToken(final String sessionId)
	{

		MagnetSession magSession = null;

		magSession = sessionOps.retrieve(sessionId);
		return magSession;

	}

	@Override
	public UserVO getUserInformation(String custCode, String userCode) throws ExceptionUserNotFound
	{

		final UserVO userVO = userDAO.getUserByCodes(custCode, userCode);

		if (userVO == null)
		{
			throw new ExceptionUserNotFound();
		}

		return userVO;

	}

	@Override
	public UserInfoVO getUserSecurityInformation(long custId, long userId)
	{

		return userDAO.getUserInfo(custId, userId);

	}

	@Override
	public String getSecurityQuestion(int questionId)
	{

		return userDAO.getRandomQuestion(questionId);
	}

	@Override
	public List<SecurityQuestion> fetchSecurityQuestionsForLeadBank(long leadbank)
	{

		final List<SecurityQuestionVO> securityQuestionsList = new ArrayList<SecurityQuestionVO>(
				userDAO.getSecurityQuestionsForLeadBank(leadbank));

		//converting SecurityQuestionVO to SecurityQuestion object. This is to simplify the object so that it wont carry unwanted values in json respnose.
		final List<SecurityQuestion> securityQuestions = securityQuestionsList.stream().map(list -> {
			final SecurityQuestion securityQuestion = new SecurityQuestion();
			securityQuestion.setQuestionId(list.getQuestionId());
			securityQuestion.setQuestion(list.getQuestion());
			return securityQuestion;
		}).collect(Collectors.toList());

		return securityQuestions;
	}

	@Override
	public boolean isUserEnabled(UserVO userVo)
	{
		final Date dbDateTime = new CalendarDAO().getCurrentTimestamp();
		if ((userVo.getDateEnabled() == null) || !CalendarUtils.onOrAfter(dbDateTime, userVo.getDateEnabled()))
		{
			return false;
		}
		return true;
	}

	@Override
	public boolean isUserInactive(UserVO userVO, String custCode)
	{
		// Get the DB datetime
		final Date dbDateTime = new CalendarDAO().getCurrentTimestamp();
		final Date dbDate = CalendarUtils.copyDateOnly(dbDateTime);
		final Date pwdDate = CalendarUtils.copyDateOnly(userVO.getLastLogin() == null ? dbDateTime : userVO.getLastLogin());
		final long daysOld = (dbDate.getTime() - pwdDate.getTime()) / (1000L * 60L * 60L * 24L);

		final LeadbankVO leadbankVO = leadbankDAO.getLeadbankByCustCode(custCode);
		if (leadbankVO != null)
		{

			if ((leadbankVO.getUserLockoutDays() != null) && (leadbankVO.getUserLockoutDays().intValue() > 0)
					&& (leadbankVO.getUserLockoutDays().intValue() <= daysOld))
			{
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean isCBEUser(String custCode)
	{
		final CustomerVO custVO = new CustomerDAO().getCustomer(custCode);

		if ((custVO != null) && (custVO.getCbeEnabled() == 1))
		{
			return true;
		}
		return false;
	}

	@Override
	public boolean checkSecurityAnswers(UserInfoVO userInfo, String answer1, String answer2, String answer3)
	{
		return userOps.checkSecurityAnswers(userInfo, answer1, answer2, answer3);
	}

	@Override
	public void updateSecurityQuestionAnswers(UserInfoVO userInfo) throws DataAccessException
	{

		userDAO.updateUserSecurityAnswers(userInfo);
	}

	@Override
	public void addSecurityQuestionAnswers(UserInfoVO userInfo) throws DataAccessException
	{

		userDAO.addUserSecurityAnswers(userInfo);
	}

	@Override
	public UserVO invalidSecurityAnswerAttempt(UserInfoVO userInfo)
	{

		userDAO.invalidAttempts(userInfo);
		final UserVO updatedUser = userDAO.getUser(userInfo.getUserId().intValue());
		if (updatedUser.getSecurityQuestionLock() == 1)
		{
			userOps.sendEmailSecurityQuestionLockout(updatedUser);
		}
		return updatedUser;
	}

	private Date getTempPasswordExpireDate()
	{
		final Date now = new Date();
		Calendar expirationTime = Calendar.getInstance();
		expirationTime.setTime(now);
		// Set calendar to the immediately previous midnight
		expirationTime = DateUtils.truncate(expirationTime, Calendar.DAY_OF_MONTH);
		final Date oneHourFromNow = DateUtils.addHours(now, 1);
		if (DateUtils.isSameDay(now, oneHourFromNow))
		{
			expirationTime.add(Calendar.DAY_OF_MONTH, 1);
		}
		else
		{
			// If 'now' is after 11 pm, advance the expire date an additional day
			expirationTime.add(Calendar.DAY_OF_MONTH, 2);
		}
		return expirationTime.getTime();
	}

	@Override
	public void doTemporaryPasswordReset(UserVO userVo, UserInfoVO userInfo)
	{
		final String key = generateKey();

		userDAO.setPasswordRaw(userVo, key, true, getTempPasswordExpireDate());// LocalDate.now());
		userOps.sendEmailForTemporaryPassword(userVo, key);
		userVo.setPasswordLockout(0);
		userVo.setInvalidLogins(0);
		userVo.setForcePasswordChange(1);
		userDAO.updateUserLockoutAndInvalidLogin(userVo);
		userDAO.resetInvalidAttempts(userInfo);
	}

	@Override
	public void updateUserFirstTimeLoginCompletionInfo()
	{
		final UserVO updatedUser = userDAO.getUser(session.getUserId());
		if (updatedUser.getLastLogin() != null)
		{
			userDAO.updateUserFirstTimeLoginCompletion(session.getUserId());
		}
		else
		{
			throw new WrapperException("INVALID_USER_STATE",
					"User last login time is null which will prevent from completing First Time Login Process");
		}
	}

	public String generateKey()
	{
		return MibsUtils.generateNumeric(6);
	}

	@Override
	public String fetchPasswordPattern(Long lbId)
	{
		final PasswordDAO passwordDAO = new PasswordDAO();
		return passwordDAO.fetchPasswordPattern(lbId);
	}

	@Override
	public String fetchPasswordPatternDescription(Long lbId)
	{
		final PasswordDAO passwordDAO = new PasswordDAO();
		return passwordDAO.fetchPasswordPatternNotice(lbId);
	}

	@Override
	public List<String> fetchPasswordInclusions(Long lbId) throws NoSuchVOException
	{
		final PasswordDAO passwordDAO = new PasswordDAO();
		final OptionVO inclusions = passwordDAO.fetchPasswordInclusions(lbId);
		return replaceStrings((List<String>) inclusions.getValues());
	}

	@Override
	public void changePassword(String custCode, String userCode, String oldUserPassword, String newUserPassword) throws Exception
	{

		userDAO.changePassword(custCode, null, userCode, oldUserPassword, newUserPassword);

		final UserVO userVO = getUserInformation(custCode, userCode);

		final String subject = "Security Notification";
		final String message = "This is a system generated alert. The password for the following user account was updated:\r\n"
				+ "\r\n" + "Customer ID: " + custCode + "\r\n" + "User ID: " + userCode + "\r\n" + "\r\n"
				+ "If you did not initiate this change or have any questions, please contact your company or bank administrator immediately.";

		Email.sendEmailBySmtpClient(null, userVO.getEmail(), subject, message, null, MimeTypes.TEXT_PLAIN);
	}

	@Override
	public Collection<TermsConditionsVO> getTermsForCorpUser(SessionVO sessionVo)
	{
		final Collection<TermsConditionsVO> usersTerms = termsBo.getTermsForCorpUser(sessionVo);

		return usersTerms;
	}

	@Override
	public void updateUserInformation(UserVO userVO)
	{
		userOps.updateUser(userVO, false, false, false);

	}

	@Override
	public List<DestinationWebWrapper> getUserSecurityContactInformation(UserVO userVo, ViewTypeRequest viewTypeRequest)
			throws ExceptionUserNotFound
	{
		final List<DestinationWebWrapper> destinationWebWrapperlst = new ArrayList<DestinationWebWrapper>();
		final MFA2CallResponse nsResponse = getDestinations(session.getSessionVo());
		if (!nsResponse.isSuccess())
		{
			return destinationWebWrapperlst;
		}

		final List<Destination> destinationList = nsResponse.getDestinations();

		if ((destinationList != null) && !destinationList.isEmpty())
		{
			for (final Destination destination : destinationList)
			{
				switch (destination.getProtocol())
				{
					case EMAIL:
					{

						final String address = destination.getAddress();
						if (ViewType.ENROLL.equals(viewTypeRequest.getViewType().name()))
						{
							if ((null == destination.getAddress()) || address.isEmpty())
							{
								destination.setAddress(userVo.getEmail());
							}
						}

						destinationWebWrapperlst.add(new DestinationWebWrapper(destination));
						break;
					}					
					default:
					{
						destinationWebWrapperlst.add(new DestinationWebWrapper(destination));
						break;
					}
				}
			}
		}

		return destinationWebWrapperlst;

	}

	@Override
	public MFA2CallResponse getDestinations(SessionVO sessionVo)
	{

		return nsClient.getDestinations(userOps.getUser(sessionVo), sessionVo, sessionVo.getLbId());

	}

	@Override
	public void updateUserSecurityContactInformation(List<Destination> destinationlst, ViewType viewType)
			throws ExceptionUserNotFound
	{

		WebHelper.validateDestinations(destinationlst);
		final UserVO userVo = getUserInformation(session.getCustomerCode(), session.getUserCode());
		final MFA2CallResponse nsResponse = nsClient.persistDestinations(userVo, destinationlst);
		if (!nsResponse.isSuccess())
		{
			return;
		}

		// Update user's Auth Mode since they are now using OTP

		cmProxy.setAuthMode(userVo.getCustCode(), userVo.getCode(), AuthSystemType.ONE_TIME_PASSCODE);

		if (viewType.name().equals(ViewType.MAINTENANCE.name()))
		{
			// Send Email to User and Administrator
			WebHelper.sendDeliveryChangeEmail(session, userVo);

		}
		//TODO: This will be done in future stories
		// FraudCheck notification section
		//        try {
		//            HttpServletRequest request = FacesUtils.getRequest();
		//TODO: Check if this is still valid in the new logic
		//            if (FraudCheckHelper.isFraudCheckEnabled(request)) {
		//                FraudCheckDelegate.getInstance(request).appendMFAOptionsChangedEvent(
		//                        request, FraudCheckCommonConstants.MFA_OPTION_CHANGE_TYPE_CHANNEL).sendOnewayAsync();
		//            }
		//        } catch (Exception e) {
		////            logger.error("OTPBean - exception occurred while calling fraud check module: "+ e.getMessage());
		//        }

	}

	@Override
	public boolean sendActivationCodeToDestinations(List<Destination> destinationList) throws ExceptionUserNotFound
	{

		final MFA2CallResponse nsResponse = nsClient.sendActivationCodeToDestinations(
			getUserInformation(session.getCustomerCode(), session.getUserCode()), destinationList);
		if (!nsResponse.isSuccess())
		{
			return false;
		}
		final MfaCode mfaCode = new MfaCode();
		mfaCode.setMfacode(nsResponse.getActivationCode());
		final MfaCodePK mfaCodePK = new MfaCodePK();
		mfaCodePK.setSessId(session.getSessionId());
		mfaCode.setId(mfaCodePK);
		mfaCode.setPasswordexpdate(new Timestamp(System.currentTimeMillis() + TimeUnit.MINUTES.toMillis(5)));
		mfaCodeDao.save(mfaCode);

		return true;

	}

	@Override
	public boolean validateActivationCode(String activationCode) throws ExceptionUserNotFound
	{

		final MfaCodePK mfaCodePK = new MfaCodePK();
		mfaCodePK.setSessId(session.getSessionId());
		final Optional<MfaCode> activeMfaCode = mfaCodeDao.findById(mfaCodePK);
		if (activeMfaCode.isPresent())
		{
			final String mfaActivationCode = activeMfaCode.map(MfaCode::getMfacode).orElse("");
			final Timestamp mfaExpirationTs = activeMfaCode.map(MfaCode::getPasswordexpdate).orElseGet(null);
			if (!mfaActivationCode.equals(activationCode))
			{
				throw new InvalidDataException("INVALID_CODE", "Activation Code is Invalid");
			}
			if ((new Timestamp(System.currentTimeMillis())).after(mfaExpirationTs))
			{

				throw new InvalidDataException("EXPIRED_CODE", "Activation Code is Expired");
			}

			return true;
		}

		return false;

	}

	public List<String> replaceStrings(List<String> list)
	{
		final ListIterator<String> it = list.listIterator();
		String code = "";
		while (it.hasNext())
		{
			code = it.next().toString();
			if (code.contains("Customer"))
			{
				it.set("customerCode");
			}
			else if (code.contains("Lead"))
			{
				it.set("leadBankCode");
			}
			else if (code.contains("User"))
			{
				it.set("userCode");
			}
		}

		return list;
	}
}
