package com.bottomline.cbe.authentication.dao.impl;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bottomline.cbe.authentication.dao.EmulationDao;
import com.bottomline.cbe.authentication.jpa.CustomersRepository;
import com.bottomline.cbe.authentication.jpa.UsersRepository;
import com.bottomline.cbe.authentication.jpa.entity.Customers;
import com.bottomline.cbe.authentication.jpa.entity.Users;
import com.bottomline.cbe.context.SessionAware;

@Repository
public class EmulationdaoImpl implements EmulationDao
{

	@Autowired
	private SessionAware session;

	@Autowired
	private CustomersRepository customersRepository;
	@Autowired
	private UsersRepository usersRepository;

	@Override
	public Map<String, String> listEmulatableCustomers()
	{
		final List<Customers> customers = customersRepository
			.findAllByCustleadbankAndCusttypeAndCbeEnabled(session.getLeadbankCode(), 'C'/* customer type */, 1);
		if (CollectionUtils.isNotEmpty(customers))
		{
			return customers.stream().collect(Collectors.toMap(Customers::getCustcode, Customers::getCustname));
		}
		return MapUtils.EMPTY_SORTED_MAP;
	}

	@Override
	public Map<String, String> listEmulatableUsers(final String customerCode)
	{
		final Optional<Customers> cusotmer = customersRepository.findByCustleadbankAndCustcodeAndCusttypeAndCbeEnabled(
			session.getLeadbankCode(), customerCode, 'C'/* customer type */, 1);
		if (cusotmer.isPresent())
		{
			final List<Users> users = usersRepository.findAllByIdUsercust(customerCode);
			if (CollectionUtils.isNotEmpty(users))
			{
				return users.stream().collect(Collectors.toMap(Users::getUserCode, Users::getUsername));
			}
		}
		return MapUtils.EMPTY_SORTED_MAP;
	}

	@Override
	public boolean isEmulatable(String customerCode, String userCode)
	{
		return listEmulatableUsers(customerCode).containsKey(userCode);
	}
}
