package com.bottomline.cbe.authentication.domain.request;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import com.magnetbanking.foundation.challengemanager.providers.mfa2.vo.Destination.Protocol;

public class SecurityContactResponse implements Serializable
{

	private Protocol contactType;
	@NotNull
	private String value;
	@NotNull
	private boolean isDefault;
	private int vruDelay;
	private String extension;

	public Protocol getContactType()
	{
		return contactType;
	}
	public void setContactType(Protocol contactType)
	{
		this.contactType = contactType;
	}
	public String getValue()
	{
		return value;
	}
	public void setValue(String value)
	{
		this.value = value;
	}
	public boolean isDefault()
	{
		return isDefault;
	}
	public void setDefault(boolean isDefault)
	{
		this.isDefault = isDefault;
	}

	public int getVruDelay()
	{
		return vruDelay;
	}

	public void setVruDelay(int vruDelay)
	{
		this.vruDelay = vruDelay;
	}

	public String getExtension()
	{
		return extension;
	}

	public void setExtension(String extension)
	{
		this.extension = extension;
	}


}
