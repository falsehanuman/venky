package com.bottomline.cbe.authentication.service.impl;

import java.util.Date;
import java.util.Map;
import java.util.Optional;

import com.magnetbanking.ibs.MCdate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bottomline.cbe.authentication.dao.EmulationDao;
import com.bottomline.cbe.authentication.domain.request.EmulationReq;
import com.bottomline.cbe.authentication.domain.response.EmulationSession;
import com.bottomline.cbe.authentication.service.EmulationService;
import com.bottomline.cbe.context.SessionIdAware;
import com.bottomline.cbe.exception.CBEBusinessException;
import com.magnetbanking.api.ecomapi.EcomConnection;
import com.magnetbanking.ibs.ecomAPI;
import com.magnetbanking.ibs.MCBaseObjPackage.ExceptionBadSession;
import com.magnetbanking.ibs.MCBaseObjPackage.ExceptionDatabase;
import com.magnetbanking.ibs.MCBaseObjPackage.ExceptionGeneric;
import com.magnetbanking.ibs.MCBaseObjPackage.ExceptionUnAuthorized;
import com.magnetbanking.ibs.ecomAPIPackage.SessionExceptionBadCust;
import com.magnetbanking.ibs.ecomAPIPackage.SessionExceptionBadUser;
import com.magnetbanking.ibs.ecomAPIPackage.SessionRec;
import com.magnetbanking.ibs.ecomAPIPackage.SessionRecHolder;

@Service
public class EmulationServiceImpl implements EmulationService
{

	@Autowired
	private EmulationDao emulationDao;
	private static final Logger LOG = LoggerFactory.getLogger(EmulationServiceImpl.class);

	@Autowired
	private SessionIdAware sessionId;

	@Override
	public Map<String, String> listEmulatableCustomers()
	{
		return emulationDao.listEmulatableCustomers();
	}

	@Override
	public Map<String, String> listEmulatableUsers(EmulationReq emulationReq)
	{
		return emulationDao.listEmulatableUsers(emulationReq.getCustomerCode());
	}

	@Override
	public Optional<EmulationSession> startEmulation(final EmulationReq emulationReq)
	{

		if(!emulationDao.isEmulatable(emulationReq.getCustomerCode(), emulationReq.getUserCode())){
			throw new CBEBusinessException("EMULATION.USER_IS_NOT_EMULATABLE", "User is not enabled for emulation");
		}

		try
		{
			ecomAPI ecomApi = EcomConnection.getConnection();
			SessionRecHolder sessionRecHolder = new SessionRecHolder();
			ecomApi.SessionStartEmulation(sessionId.getSessionId(), emulationReq.getCustomerCode(), emulationReq.getUserCode(),
				false/* not billable */, sessionRecHolder);
			SessionRec sessionRec = sessionRecHolder.value;
			final EmulationSession emulationSession = new EmulationSession();
			emulationSession.setAuthenticationId(sessionRec.sessId);
			emulationSession.setCustCode(sessionRec.customer);
			emulationSession.setUserCode(sessionRec.user);
			emulationSession.setStartTime(null); // FIXME read from sessions table
			LOG.debug("Emulation session started for customer:{}, user:{},sessionId:{}", emulationSession.getCustCode(),
				emulationSession.getUserCode(), emulationSession.getAuthenticationId());
			return Optional.of(emulationSession);
		}
		catch (SessionExceptionBadUser | SessionExceptionBadCust | ExceptionGeneric | ExceptionDatabase | ExceptionBadSession
				| ExceptionUnAuthorized e)
		{
			LOG.error("Error occured starting emulation for customer:{} and user:{}", emulationReq.getCustomerCode(),
					emulationReq.getUserCode());
			throw new CBEBusinessException("COMMON.DATA_ACCESS_ERROR", "error in initating emulation session.", e);
		}
	}

}
