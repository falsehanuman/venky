package com.bottomline.cbe.authentication;

public class MessageConstants {

	public static final String ID_MISSING = "AUTH0017";
	public static final String ID_MISMATCH = "AUTH0016";
	public static final String NO_SECURITY_QUESTIONS = "AUTH0007";
	public static final String NO_EMAIL_ID = "AUTH0008";
	public static final String USER_LOCKED_OUT = "USER_LOCKED_OUT";
	public static final String USER_NOT_ENABLED = "AUTH0009";
	public static final String INACTIVE_USER= "AUTH0006";
	public static final String SECURITY_QUESTION_ANSWERS_INVALID = "SECURITY_QUESTION_ANSWERS_INVALID";
	public static final String EXCESS_INVALID_ATTEMPTS = "EXCESS_INVALID_ATTEMPTS";
	public static final String PASSWORD_MISSING = "PASSWORD_MISSING";
	public static final String PASSWORD_USED_TOO_RECENTLY = "PASSWORD_USED_TOO_RECENTLY";
	public static final String PASSWORD_LENGTH_INVALID = "PASSWORD_LENGTH_INVALID";
	public static final String PASSWORD_HAS_ILLEGAL_CHARS = "PASSWORD_HAS_ILLEGAL_CHARS";
	public static final String PASSWORD_IS_NOT_VALID = "PASSWORD_IS_NOT_VALID";
	public static final String LEADBANK_NOT_FOUND = "COMMON.LEADBANK_NOT_FOUND";
	public static final String USER_ADMIN_lOCKED = "AUTH0015";
	public static final String EXCESS_INVALID_SECURITY_QUESTION_ANSWERS_ATTEMPTS = "AUTH0010";
	public static final String DATABASE_EXCEPTION = "DATABASE_EXCEPTION";
	public static final String NO_BULLETIN_MESSAGES = "NO_BULLETIN_MESSAGES";
	public static final String TERMS_CONDITIONS_NOT_FOUND = "TERMS_CONDITIONS_NOT_FOUND";
	public static final String NOT_A_BANK_CUSTOMER = "NOT_A_BANK_CUSTOMER";
	public static final String INVALID_SECURITY_KEY = "INVALID_SECURITY_KEY";
}
