package com.bottomline.cbe.authentication.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bottomline.cbe.authentication.service.SessionService;
import com.bottomline.cbe.context.SessionAware;
import com.bottomline.foundation.session.vo.SessionVO;
import com.magnetbanking.foundation.session.dao.MagnetSessionDAO;
import com.magnetbanking.foundation.session.iface.BadSession;
import com.magnetbanking.foundation.session.iface.MagnetSession;
import com.magnetbanking.foundation.session.iface.MagnetSessionOps;
import com.magnetbanking.foundation.session.vo.LoginInfoVO;
import com.magnetbanking.foundation.session.vo.MagnetSessionAdaptor;
import com.magnetbanking.util.activity.Activity;

@Service
public class SessionServiceImpl implements SessionService
{
	@Autowired
	private SessionAware session;

	@Autowired
	MagnetSessionOps sessionOps;

	Logger LOGGER = LoggerFactory.getLogger(SessionServiceImpl.class);

	@Override
	public void deactivateSession() throws BadSession
	{

		//				final MagnetSession sessionAdapter = new MagnetSessionAdaptor(session.getSessionVo(), new LoginInfoVO());
		//				sessionAdapter.deactivate(session.getSessionId());
		new MagnetSessionDAO().deactivate(session.getSessionId());
		Activity.insertRawAuditRecord(session.getUserId().longValue(), session.getCustomerCode(), session.getUserCode(),
			session.getSessionId(), "Logout", "Logout", 0, 1, "User logged out", session.getLeadbankCode(), "0");
	}

	@Override
	public boolean isValidSession(SessionVO session) throws BadSession
	{

		final MagnetSession sessionAdapter = new MagnetSessionAdaptor(session, new LoginInfoVO());
		return sessionAdapter.isValid();
	}

	/**
	 * This method returns the current session remaining time to expire
	 *
	 * @param sid
	 * @return
	 */
	@Override
	public Long getSessionTimeRemaining(String sid) throws BadSession
	{
		final MagnetSessionDAO magnetSessionDao = new MagnetSessionDAO();

		return magnetSessionDao.getTimeRemaining(sid);
	}

	/**
	 * This method is used to track if User accepts to extend the session timeout
	 */
	@Override
	public void getAuditSessionTimeExtension() throws BadSession
	{
		if (session.isEmulationSession())
		{
			final SessionVO emulatorSession = sessionOps.retrieve(session.getEmulatorSessionId()).getSessionVo();
			Activity.insertRawAuditRecord(emulatorSession.getUserId().longValue(), emulatorSession.getCustCode(),
				emulatorSession.getUserCode(), "0", "Session", "Extend SessionTime", 0, 1,
				"Emulating user session time extended", "", "0");

		}
		Activity.insertRawAuditRecord(session.getUserId().longValue(), session.getCustomerCode(), session.getUserCode(), "0",
			"Session", "Extend SessionTime", 0, 1, "User attempted to extend the session time", "", "0");

	}
}
