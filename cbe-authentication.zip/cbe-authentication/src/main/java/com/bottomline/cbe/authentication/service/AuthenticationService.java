package com.bottomline.cbe.authentication.service;

import java.util.Collection;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.bottomline.cbe.authentication.bean.SecurityQuestion;
import com.bottomline.cbe.authentication.domain.request.ViewTypeRequest;
import com.bottomline.cbe.authentication.domain.request.ViewTypeRequest.ViewType;
import com.bottomline.cbe.authentication.domain.response.AuthenticationResponse;
import com.bottomline.foundation.session.vo.SessionVO;
import com.magnetbanking.foundation.challengemanager.providers.mfa2.vo.Destination;
import com.magnetbanking.foundation.challengemanager.providers.mfa2.vo.DestinationWebWrapper;
import com.magnetbanking.foundation.challengemanager.providers.mfa2.vo.MFA2CallResponse;
import com.magnetbanking.foundation.session.iface.MagnetSession;
import com.magnetbanking.foundation.session.vo.LoginRequestContextVO;
import com.magnetbanking.foundation.terms.vo.TermsConditionsVO;
import com.magnetbanking.foundation.users.vo.UserInfoVO;
import com.magnetbanking.foundation.users.vo.UserVO;
import com.magnetbanking.ibs.ecomAPIPackage.ExceptionUserNotFound;
import com.magnetbanking.util.exceptions.DataAccessException;
import com.magnetbanking.util.exceptions.NoSuchVOException;
//import com.magnetbanking.util.exceptions.TemporaryPasswordExpiredException;

public interface AuthenticationService
{

	public AuthenticationResponse login(String customerCode, String userCode, String userPassword,
			LoginRequestContextVO loginContext, HttpServletRequest httpRequest) throws Exception;

	/**
	 * Finds a user by its dao-key.
	 *
	 * @param token
	 *            user dao key
	 * @return
	 */
	MagnetSession findByToken(String token);

	UserVO getUserInformation(String custCode, String userCode) throws ExceptionUserNotFound;

	void updateUserInformation(UserVO userVO);

	UserInfoVO getUserSecurityInformation(long custId, long userId);

	String getSecurityQuestion(int questionId);

	public List<SecurityQuestion> fetchSecurityQuestionsForLeadBank(long leadbank);

	boolean isUserEnabled(UserVO userVo);

	boolean checkSecurityAnswers(UserInfoVO userInfo, String answer1, String answer2, String answer3);

	public void updateSecurityQuestionAnswers(UserInfoVO userInfo) throws DataAccessException;

	public void addSecurityQuestionAnswers(UserInfoVO userInfo) throws DataAccessException;

	UserVO invalidSecurityAnswerAttempt(UserInfoVO userInfo);

	void doTemporaryPasswordReset(UserVO userVo, UserInfoVO userInfo);

	public String fetchPasswordPattern(Long lbId);

	public String fetchPasswordPatternDescription(Long lbId);

	public List<String> fetchPasswordInclusions(Long lbId) throws NoSuchVOException;

	public void changePassword(String custCode, String UserCode, String oldUserPass, String newUserPass) throws Exception;

	public Collection<TermsConditionsVO> getTermsForCorpUser(SessionVO sessionVo);

	public List<DestinationWebWrapper> getUserSecurityContactInformation(UserVO userVo, ViewTypeRequest view)
			throws ExceptionUserNotFound;

	public void updateUserSecurityContactInformation(List<Destination> destinationlst, ViewType viewType)
			throws ExceptionUserNotFound;

	public boolean sendActivationCodeToDestinations(List<Destination> destinationList) throws ExceptionUserNotFound;

	public boolean validateActivationCode(String activationCode) throws ExceptionUserNotFound;

	public MFA2CallResponse getDestinations(SessionVO sessionVo);

	void updateUserFirstTimeLoginCompletionInfo();

	public boolean isUserInactive(UserVO userVO, String custCode);

	public boolean isCBEUser(String custCode);
}
