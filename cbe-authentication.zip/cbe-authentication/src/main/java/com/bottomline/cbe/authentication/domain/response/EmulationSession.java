package com.bottomline.cbe.authentication.domain.response;

import java.io.Serializable;
import java.util.Date;

import javax.validation.Valid;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.bottomline.cbe.document.JiraRef;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import io.swagger.annotations.ApiModel;

/**
 *
 * @author ravi.pulluri
 *
 */

@JsonPropertyOrder(alphabetic = true)
@ApiModel(value = "EmulationSession")
@Valid
@JiraRef(value = { "CB-25954" })

public class EmulationSession implements Serializable
{

	private static final long serialVersionUID = 1L;

	@JsonProperty("authenticationId")
	private String authenticationId;

	@JsonProperty("userCode")
	private String userCode;

	@JsonProperty("customerCode")
	private String custCode;

	@JsonProperty("startTime")
	private Date startTime;

	public String getAuthenticationId()
	{
		return authenticationId;
	}

	public void setAuthenticationId(String authenticationId)
	{
		this.authenticationId = authenticationId;
	}

	public String getUserCode()
	{
		return userCode;
	}

	public void setUserCode(String userCode)
	{
		this.userCode = userCode;
	}

	public String getCustCode()
	{
		return custCode;
	}

	public void setCustCode(String custCode)
	{
		this.custCode = custCode;
	}

	public void setStartTime(Date startTime)
	{
		this.startTime = startTime;
	}

	public Date getStartTime()
	{
		return startTime;
	}

	@Override
	public String toString()
	{
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

}
