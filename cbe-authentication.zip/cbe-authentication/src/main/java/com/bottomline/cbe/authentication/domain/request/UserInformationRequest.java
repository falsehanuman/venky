package com.bottomline.cbe.authentication.domain.request;

import java.io.Serializable;


import javax.validation.constraints.Size;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.hibernate.validator.constraints.Email;

import com.bottomline.cbe.servicescore.validation.constratints.NotBlank;
import com.fasterxml.jackson.annotation.JsonProperty;



public class UserInformationRequest extends UserResourceRequest implements Serializable {

	private static final long serialVersionUID = 1L;
	@Size(max=40, message="MAX_SIZE_EXCEEDED")
	@NotBlank(message="MISSING_REQUIRED_FIELD")
	private String userName;
	@Size(max=40, message="MAX_SIZE_EXCEEDED")
	private String address1;
	@Size(max=40, message="MAX_SIZE_EXCEEDED")
	private String address2;
	@Size(max=40, message="MAX_SIZE_EXCEEDED")
	private String city;
	@Size(max=25, message="MAX_SIZE_EXCEEDED")
	private String state;
	@Size(max=25, message="MAX_SIZE_EXCEEDED")
	private String postalCode;	
	@JsonProperty("phoneNumber")
	@Size(max=25, message="MAX_SIZE_EXCEEDED")
	private String voicePhone;
	@Size(max=25, message="MAX_SIZE_EXCEEDED")
	private String faxNumber;
	@SuppressWarnings("deprecation")
	@Size(max=255, message="MAX_SIZE_EXCEEDED")
	@NotBlank(message="MISSING_REQUIRED_FIELD")
	@Email(message="INVALID_EMAIL")
	private String email;
	
	public String getUserName()
	{
		return userName;
	}

	public void setUserName(String userName)
	{
		this.userName = userName;
	}

	public String getAddress1()
	{
		return address1;
	}

	public void setAddress1(String address1)
	{
		this.address1 = address1;
	}

	public String getAddress2()
	{
		return address2;
	}

	public void setAddress2(String address2)
	{
		this.address2 = address2;
	}

	public String getCity()
	{
		return city;
	}

	public void setCity(String city)
	{
		this.city = city;
	}

	public String getState()
	{
		return state;
	}

	public void setState(String state)
	{
		this.state = state;
	}

	public String getPostalCode()
	{
		return postalCode;
	}

	public void setPostalCode(String postalCode)
	{
		this.postalCode = postalCode;
	}

	public String getVoicePhone()
	{
		return voicePhone;
	}

	public void setVoicePhone(String voicePhone)
	{
		this.voicePhone = voicePhone;
	}

	public String getFaxNumber()
	{
		return faxNumber;
	}

	public void setFaxNumber(String faxNumber)
	{
		this.faxNumber = faxNumber;
	}

	public String getEmail()
	{
		return email;
	}

	public void setEmail(String email)
	{
		this.email = email;
	}

		@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}

	
	
}
