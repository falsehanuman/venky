package com.bottomline.cbe.authentication.jpa.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "login_challenge")
public class LoginChallenge
{
	@Id
	@Column(name = "challenge_sess_id")
	private String challengeSessionId;

	@Column(name = "sess_id")
	private String sessionId;

	public String getChallengeSessionId()
	{
		return challengeSessionId;
	}

	public void setChallengeSessionId(String challengeSessionId)
	{
		this.challengeSessionId = challengeSessionId;
	}

	public String getSessionId()
	{
		return sessionId;
	}

	public void setSessionId(String sessionId)
	{
		this.sessionId = sessionId;
	}
}
