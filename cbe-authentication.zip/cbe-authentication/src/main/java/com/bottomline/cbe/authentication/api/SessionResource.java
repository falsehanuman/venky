package com.bottomline.cbe.authentication.api;

import static com.bottomline.cbe.servicescore.interceptor.AuthorizationCheckInterceptor.AUTHORIZATION;

import java.net.InetAddress;
import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.Collection;
import java.util.GregorianCalendar;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bottomline.cbe.authentication.MessageConstants;
import com.bottomline.cbe.authentication.domain.request.AuthenticationRequest;
import com.bottomline.cbe.authentication.domain.request.LogoffRequest;
import com.bottomline.cbe.authentication.domain.response.AuthenticationResponse;
import com.bottomline.cbe.authentication.domain.response.LoginChallengeResponse;
import com.bottomline.cbe.authentication.domain.response.SessionTimeResponse;
import com.bottomline.cbe.authentication.domain.response.UserInformationResponse;
import com.bottomline.cbe.authentication.jpa.LoginChallengeRepository;
import com.bottomline.cbe.authentication.jpa.entity.LoginChallenge;
import com.bottomline.cbe.authentication.service.AuthenticationService;
import com.bottomline.cbe.authentication.service.SessionService;
import com.bottomline.cbe.challengemanager.ChallengeManager;
import com.bottomline.cbe.challengemanager.ChallengeManagerConfiguration;
import com.bottomline.cbe.challengemanager.ChallengePoint;
import com.bottomline.cbe.challengemanager.ChallengeResponse;
import com.bottomline.cbe.challengemanager.ChallengeTypes;
import com.bottomline.cbe.challengemanager.VipChallengeManager;
import com.bottomline.cbe.challengemanager.VipServiceImpl;
import com.bottomline.cbe.context.FIContextAware;
import com.bottomline.cbe.context.HeaderContextParams;
import com.bottomline.cbe.context.SessionAware;
import com.bottomline.cbe.exception.CBEBusinessException;
import com.bottomline.cbe.servicescore.annotation.AllowEmulation;
import com.bottomline.cbe.servicescore.annotation.AllowedOnly;
import com.bottomline.cbe.servicescore.annotation.PublicApi;
import com.bottomline.cbe.servicescore.domain.response.BasicResponse;
import com.bottomline.cbe.servicescore.domain.response.StandardResponse;
import com.bottomline.cbe.servicescore.exception.ChallengeManagerException;
import com.bottomline.cbe.servicescore.exception.FailedChallengeException;
import com.bottomline.cbe.servicescore.util.CBEContextAwareBeanLoader;
import com.bottomline.foundation.session.vo.SessionVO;
import com.magnetbanking.foundation.asp.context.AspContextLocator;
import com.magnetbanking.foundation.challengemanager.dao.ChallengeManagerDAO;
import com.magnetbanking.foundation.challengemanager.providers.mfa2.bo.NSClientBo;
import com.magnetbanking.foundation.challengemanager.providers.mfa2.vo.MFA2CallResponse;
import com.magnetbanking.foundation.challengemanager.vo.AuthSystemType;
import com.magnetbanking.foundation.dichallenge.util.DIChallengeUtils;
import com.magnetbanking.foundation.fraudcheck.ga.enums.GALogonStatusEnum;
import com.magnetbanking.foundation.fraudcheck.util.FraudCheckHelper;
import com.magnetbanking.foundation.fraudcheck.util.FraudCheckRequestUtils;
import com.magnetbanking.foundation.fraudcheck.wpf.service.WPFService;
import com.magnetbanking.foundation.infrastructure.option.iface.OptionConstants;
import com.magnetbanking.foundation.infrastructure.option.impl.OptionManager;
import com.magnetbanking.foundation.infrastructure.option.vo.OptionDefault;
import com.magnetbanking.foundation.leadbank.dao.LeadbankDAO;
import com.magnetbanking.foundation.logon.web.LogonUtils;
import com.magnetbanking.foundation.session.dao.MagnetSessionDAO;
import com.magnetbanking.foundation.session.dao.PremierRedirectDAO;
import com.magnetbanking.foundation.session.enums.ChannelType;
import com.magnetbanking.foundation.session.filter.ChallengeUtils;
import com.magnetbanking.foundation.session.iface.BadSession;
import com.magnetbanking.foundation.session.vo.LoginRequestContextVO;
import com.magnetbanking.foundation.session.vo.PremierRedirectVO;
import com.magnetbanking.foundation.terms.vo.TermsConditionsVO;
import com.magnetbanking.foundation.users.dao.UserDAO;
import com.magnetbanking.foundation.users.vo.UserInfoVO;
import com.magnetbanking.foundation.users.vo.UserVO;
import com.magnetbanking.ibs.ecomAPIPackage.ExceptionUserNotFound;
import com.magnetbanking.util.MibsUtils;
import com.magnetbanking.util.activity.Activity;

import io.swagger.annotations.ApiOperation;

//import com.bottomline.cbe.challengemanager.ChallengeableEndpoint;
//import com.bottomline.cbe.servicescore.annotation.Challengeable;

/**
 *
 * @author ravi.pulluri
 *
 */

@RestController
public class SessionResource
{

	private static final Logger logger = LoggerFactory.getLogger(SessionResource.class);

	@Autowired
	AuthenticationService authenticationService;

	@Autowired
	SessionService sessionService;

	@Autowired
	SessionAware session;

	@Autowired
	NSClientBo nsClient;

	@Autowired
	LeadbankDAO leadbankDAO;

	@Autowired
	FIContextAware fiContext;

	@Autowired
	DIChallengeUtils diChallengeUtils;

	@Autowired
	WPFService wpfService;

	@Autowired
	MagnetSessionDAO magnetSessionDAO;

	@Autowired
	PremierRedirectDAO premierRedirectDAO;

	@Autowired
	VipServiceImpl vipService;

	private static final String DEVICE_TOKENS = "DEVICE-TOKENS";

	@Autowired
	private ChallengeManagerConfiguration challengeManagerConfiguration;
	@Autowired
	private ChallengeManager challengeManager;
	@Autowired
	private VipChallengeManager vipChallengeManager;
	@Autowired
	private CBEContextAwareBeanLoader cbeContextBeanLoader;
	@Autowired
	private LoginChallengeRepository loginChallengeRepository;
	@Autowired
	private FraudCheckRequestUtils fraudCheckRequestUtils;

	@Autowired
	private VipServiceImpl vipServiceImpl;


	public com.bottomline.cbe.servicescore.domain.response.StandardResponse<AuthenticationResponse> login(
			@Valid @RequestBody final AuthenticationRequest request, HttpServletRequest httpRequest) throws Exception
	{

		final StandardResponse<AuthenticationResponse> resp = new StandardResponse<AuthenticationResponse>();
		ChannelType channel = null;
		if ((fiContext.getChannelType() != null) && (fiContext.getChannelType() != ChannelType.UNKNOWN))
		{
			channel = fiContext.getChannelType();
		}
		else
		{
			logger.warn("{} header missing, defaulting to WEB2", HeaderContextParams.X_CHANNEL_NAME.code());
			channel = ChannelType.WEB2;
		}
		final LoginRequestContextVO ctx = new LoginRequestContextVO(channel);
		//CB-38803
		final String ip = httpRequest.getHeader("X-Real-IP") != null ? httpRequest.getHeader("X-Real-IP") : httpRequest.getRemoteAddr();
		if ((ip != null) && ip.contains(":")) {
			ctx.setClientIpAddress(InetAddress.getByName("127.0.0.1"));
		} else {
			ctx.setClientIpAddress(InetAddress.getByName(ip));
		}
		logger.info("SessionResource :: Login : IP address: "+ip);
		final AuthenticationRequest authRequest = new AuthenticationRequest(request.getCustCode(), request.getUserCode(), request.getUserPwd());
		if(request.getRedirectToken()!=null && !request.getRedirectToken().trim().isEmpty())
		{
			// Login redirected from BFS login screen so get user credentials from DB and set flag in LoginContextRequestVO
			PremierRedirectVO redirect = new PremierRedirectDAO().useRedirect(request.getRedirectToken());
			if(redirect!=null)
			{
				authRequest.setCustCode(redirect.getCustCode());
				authRequest.setUserCode(redirect.getUserCode());
				authRequest.setUserPwd(redirect.getHashedPass());
				ctx.setIsSSOLogin(true);
			} else {
				logger.error("SessionResource :: Login : Redirect detected but record not found in database or was too old: "+request.getRedirectToken());
			}
		}
		final AuthenticationResponse authResponse = authenticationService.login(authRequest.getCustCode(), authRequest.getUserCode(),
				authRequest.getUserPwd(), ctx, httpRequest);
		authResponse.setTimeZone(new GregorianCalendar().getTimeZone().getID());
		authResponse.setChannel(channel.name());

		SessionVO sessionVO = fraudCheckRequestUtils.getSession(authResponse.getAuthenticationId());
		if (FraudCheckHelper.isWPF(sessionVO.getLbId()))
		{
			wpfService.processWPFLogin(AspContextLocator.getCurrent(), httpRequest.getHeader("User-Agent"),
				httpRequest.getRemoteAddr(), authResponse.getAuthenticationId());
		}
		resp.setData(authResponse);
		resp.setResponseOK();
		return resp;
	}

	@PublicApi
	@PostMapping(value = "/public/session/login", produces = "application/json", consumes = "application/json")
	@ApiOperation(value = "Login", notes = "User Login API")
	public StandardResponse<AuthenticationResponse> loginAndChallengeIfNeeded(
			@Valid @RequestBody final AuthenticationRequest request, HttpServletRequest httpRequest) throws Exception
	{
		if (validatePasscode(httpRequest))
		{
			return getUserSessionInfo(httpRequest);
		}

		final StandardResponse<AuthenticationResponse> loginResponse = login(request, httpRequest);

		final AuthenticationResponse authenticationResponse = loginResponse.getData();
		cbeContextBeanLoader.loadSessionAware(authenticationResponse.getAuthenticationId(), httpRequest.getRequestURI());

		final String challengePointServiceCode = authenticationResponse.getChallengePointServiceCode();

		// TODO: Once we have a ChallengeManger interface this can return the correct implementation
		// TODO: and we will not need this if then else that we have now for testing.
		final Pair<String, String> challengePoint = new ImmutablePair<>(challengePointServiceCode,
				challengeManager.findChallengePointName(challengePointServiceCode));
		if (challengeManager.shouldChallenge(challengePoint))
		{

			//challenge point pair contains the challenge point's service code and name

			final LoginChallengeResponse challenge = challengeLogin(authenticationResponse,
				challengeManagerConfiguration.getChallengeManager());
			challenge.setChallengeFirstAttempt(true);
			
			return buildResponse(challenge);
		}
		
		SessionVO sessionVO = fraudCheckRequestUtils.getSession(authenticationResponse.getAuthenticationId());
		if (!authenticationResponse.getBankUser() && FraudCheckHelper.isFraudMap(sessionVO.getLbId()))
		{
				makeFraudMapCall(authenticationResponse, httpRequest, sessionVO);

		}
		
		return loginResponse;
	}

	private LoginChallengeResponse challengeLogin(AuthenticationResponse authenticationResponse, AuthSystemType authSystemType)
	{
		final int SID_KEY_LENGTH = 50;
		final boolean GENERATE_TIMESTAMP = false;
		final String sid = MibsUtils.generateSid(SID_KEY_LENGTH, GENERATE_TIMESTAMP);

		final LoginChallenge loginChallenge = new LoginChallenge();
		loginChallenge.setChallengeSessionId(sid);
		loginChallenge.setSessionId(authenticationResponse.getAuthenticationId());

		loginChallengeRepository.save(loginChallenge);
		ChallengeResponse challengeResponse = new ChallengeResponse();
		if (authSystemType == AuthSystemType.VIP)
		{
			challengeResponse = vipChallengeManager.buildChallengeResponse(sid, vipServiceImpl.getTokenStatus());

		}
		else if (authSystemType == AuthSystemType.ONE_TIME_PASSCODE)
		{

			challengeResponse=challengeManager.challenge(sid);

		}
		else
		{
			throw new CBEBusinessException(MessageConstants.ID_MISMATCH, "Unsupported Authentication Type");
		}
		return new LoginChallengeResponse(challengeResponse,
			authenticationResponse);
	}

	private StandardResponse buildResponse(ChallengeResponse challenge)
	{
		final StandardResponse response = new StandardResponse<>();
		response.setData(challenge);
		response.setResponseOK();
		return response;
	}

	public boolean validatePasscode(HttpServletRequest httpRequest)
	{
		final String passcode = httpRequest.getHeader(ChallengeManager.PASSCODE_HEADER_NAME);
		final String nextPasscode = httpRequest.getHeader(VipChallengeManager.NEXT_PASSCODE_HEADER_NAME);
		if(StringUtils.isEmpty(passcode))
		{
			return false;
		}
		final String tempSessionId = cbeContextBeanLoader.getToken(httpRequest.getHeader(AUTHORIZATION));
		final Optional<LoginChallenge> dbRecord = loginChallengeRepository.findById(tempSessionId);
		if(dbRecord.isPresent())
		{
			final String sessionId = dbRecord.get().getSessionId();
			cbeContextBeanLoader.loadSessionAware(sessionId, httpRequest.getRequestURI());
			boolean isValidPasscode = false;
			try
			{
				final AuthSystemType authSystemType = challengeManagerConfiguration.getChallengeManager();
				if ( authSystemType== AuthSystemType.VIP)
				{
					//TODO: Uncomment it when caching is put in place and comment 291 to 306 and 316 to 324.Since DBIQP UI already has the token state rely on that until caching is enabled.
					//					final ChallengeTypes challengeTypes = vipService.getTokenStatus();
					//					if (!ChallengeTypes.VIP_UNAVAILABLE.equals(challengeTypes) && !StringUtils.isEmpty(passcode))
					//					{
					//						if (ChallengeTypes.VIP_ACTIVATION.equals(challengeTypes) && StringUtils.isEmpty(nextPasscode))
					//						{
					//
					//							final ChallengeResponse challengeResponse = vipChallengeManager
					//									.buildChallengeResponse(sessionId, challengeTypes);
					//							throw new ChallengeManagerException(challengeResponse);
					//						}
					ChallengeTypes challengeTypes = ChallengeTypes.VIP_CHALLENGE;
					if (StringUtils.isEmpty(passcode))
					{

						final ChallengeResponse challengeResponse = vipChallengeManager
								.buildChallengeResponse(sessionId, vipService.getTokenStatus());
						challengeResponse.setChallengeFirstAttempt(true);
						challengeResponse.setSessionId(tempSessionId);
						throw new ChallengeManagerException(challengeResponse);

					}
					else
					{
						if (!StringUtils.isEmpty(nextPasscode) && !StringUtils.contains(nextPasscode, "undefined"))
						{

							challengeTypes = ChallengeTypes.VIP_ACTIVATION;
						}
					}

					Activity.log(session.getSessionVo(), VipChallengeManager.CHALLENGE_MANAGER_SVC, 1, 0, "VIP Token entered",
							"0");
					try
					{
						isValidPasscode = vipChallengeManager.validateChallengePasscode(sessionId, passcode,
							ChallengePoint.LOGIN.getSvcCode(), challengeTypes, nextPasscode);
					}
					catch (final ChallengeManagerException smex)
					{
						smex.getChallengeResponse().getData().setSessionId(tempSessionId);
						throw smex;
					}


				}
				//				else
				//				{
				//
				//					final ChallengeResponse challengeResponse = vipChallengeManager.buildChallengeResponse(sessionId,
				//						challengeTypes);
				//					challengeResponse.setChallengeFirstAttempt(true);
				//					throw new ChallengeManagerException(challengeResponse);
				//				}
				//			}
				else if (authSystemType == AuthSystemType.ONE_TIME_PASSCODE)
				{

					isValidPasscode = challengeManager.validateChallengePasscode(sessionId, passcode, ChallengePoint.LOGIN.getSvcCode());
				}
			}
			catch (final FailedChallengeException e)
			{	//replace session id with temporary session id then re-throw
				e.getFailedChallengeResponse().getData().setSessionId(tempSessionId);
				throw e;
			}
			if(isValidPasscode)
			{
				 fraudCheckRequestUtils.populateAuthAndSendLoginEventIfFCEnabled(LogonUtils.LogonStatus.SUCCESSFUL,
					  "Success", ChallengeUtils.ChallengeReason.USER_ACCESS_RESTRICTED, session.getSessionVo(), false, true);
				 
				loginChallengeRepository.deleteById(tempSessionId);
				return true;
			}
			else
			{
				fraudCheckRequestUtils.populateAuthAndSendLoginEventIfFCEnabled(LogonUtils.LogonStatus.FAILED_AUTHENTICATION,
					GALogonStatusEnum.FAILED_AUTHENTICATION.getValidApiValue(), ChallengeUtils.ChallengeReason.USER_ACCESS_RESTRICTED, session.getSessionVo(), false, true);
			}
		}
		return false;
	}


	@ApiOperation(value = "Log off", notes = "used to log-off a session. It returns bank user session when this is requested from emulation session.")
	@RequestMapping(value = "/session/logoff", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	@AllowedOnly(anyBankPerson = true, anyCustomerUser = true)
	@AllowEmulation
	public StandardResponse<String> deactivateSession(@RequestBody final LogoffRequest request) throws BadSession, RemoteException
	{

		final StandardResponse<String> resp = new StandardResponse<>();
		if (session.isEmulationSession())
		{
			resp.setData(session.getEmulatorSessionId());
		}
		
		sessionService.deactivateSession();
		
		//Fraudmap integration
		fraudCheckRequestUtils.sendUserLoggedOut(request.isSessionExpired());
				
		final String userMessage = "User Logged off";
		resp.setResponseOK(userMessage, "User Session Ended");
		return resp;
	}

	@ApiOperation(value = "Validate User Session", notes = "Validates the User session")
	@RequestMapping(value = "/session/validate", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	@AllowEmulation
	@AllowedOnly(anyBankPerson = true, anyCustomerUser = true)
	public BasicResponse validateSession() throws BadSession, RemoteException
	{

		final BasicResponse resp = new BasicResponse();
		logger.debug("Validating User session: " + session.getUserCode());
		sessionService.isValidSession(session.getSessionVo());

		final String userMessage = "User Session is Valid";
		resp.setResponseOK(userMessage, "User Session is Valid");
		return resp;
	}

	@ApiOperation(value = "Get User Session information", notes = "Fetch the User session information")
	@RequestMapping(value = "/session/getUserSessionInfo", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	@AllowedOnly(anyCustomerUser = true, anyBankPerson = true)
	@AllowEmulation
	public StandardResponse<AuthenticationResponse> getUserSessionInfo(HttpServletRequest httpRequest)
			throws BadSession, RemoteException, ExceptionUserNotFound, Exception
	{

		final StandardResponse<AuthenticationResponse> resp = new StandardResponse<AuthenticationResponse>();
		final AuthenticationResponse authResponse = new AuthenticationResponse();
		final UserVO userVo = authenticationService.getUserInformation(session.getCustomerCode(), session.getUserCode());

		authResponse.setEmulationSession(session.isEmulationSession());
		authResponse.setAuthenticationId(session.getSessionId());
		authResponse.setShowPasswdExpWarning(false);
		authResponse.setLastloginTime(userVo.getLastLogin());
		authResponse.setUserName(userVo.getName());
		authResponse.setUserCode(userVo.getCode());
		authResponse.setCustCode(userVo.getCustCode());
		authResponse.setBankUser(session.isBankUser());

		final UserInformationResponse userInfo = new UserInformationResponse();
		userInfo.setAddress1(userVo.getAddress1());
		userInfo.setAddress2(userVo.getAddress2());
		userInfo.setCity(userVo.getCity());
		userInfo.setState(userVo.getState());
		userInfo.setPostalCode(userVo.getZip());
		userInfo.setEmail(userVo.getEmail());
		userInfo.setVoicePhone(userVo.getVoicePhone());
		userInfo.setFaxNumber(userVo.getFaxPhone());
		final UserInfoVO userInfoVO = new UserDAO().getUserInfo(userVo.getCustId(), userVo.getId());

		authResponse.setUserInformation(userInfo);

		if (!session.isEmulationSession())
		{
			final Collection<TermsConditionsVO> usersTerms = authenticationService.getTermsForCorpUser(session.getSessionVo());

			if ((usersTerms != null) && !usersTerms.isEmpty())
			{
				authResponse.setHasTermsAndConditions(true);
			}
			authResponse.setChangePassword((userVo.getForcePasswordChange() != 0) ? true : false);
			authResponse.setSecAnsNeeded(null == userInfoVO);

			//			upddated the code for CB-31895. Acutally there is no issue with the below commented line but just making sure that sessionVo is not failing.
			/*authResponse.setDeviceInfoAvailable(
				diChallengeUtils.isValidDeviceToken(httpRequest.getHeader(DEVICE_TOKENS), session.getSessionVo()));*/
			final MagnetSessionDAO magnetSessionDAO = new MagnetSessionDAO();
			final SessionVO sessionVo = magnetSessionDAO.retrieve(session.getSessionId());


			if (nsClient.isMFA2Enabled(leadbankDAO.getLeadbank(session.getLeadbankCode()), sessionVo))
			{

				authResponse.setMfaEnabled(true);
				if ("1".equals(OptionManager.getOption(OptionDefault.OTP_ENABLE_VOICE_CONTACT, session.getLeadbankId())))
				{
					authResponse.setVoiceEnabled(true);
				}
				final MFA2CallResponse nsResponse = authenticationService.getDestinations(sessionVo);
				if (nsResponse.isSuccess() && (nsResponse.getDestinations() != null) && !nsResponse.getDestinations().isEmpty())
				{
					authResponse.setSecurityContactRequired(false);
					final ChallengeManagerDAO cmDAO = new ChallengeManagerDAO();
					//The below is not required as the login api will make the entry for OTP AUth type if its absent
					//					if (cmDAO.getAuthMode(userVo.getCustCode(), userVo.getCode()) == null)
					//					{
					//					cmProxy.setAuthMode(userVo.getCustCode(), userVo.getCode(), AuthSystemType.ONE_TIME_PASSCODE);
					//					}
				}
				else
				{
					authResponse.setSecurityContactRequired(true);
				}

			}

			authResponse.setFirstLogin(
				(userVo.getLastLogin() == null)
				|| magnetSessionDAO.determineLegacyFirstTimeLoginUser(userVo, userInfoVO,
					authResponse.isSecurityContactRequired(), null));
			if (authResponse.isFirstLogin())
			{
				authResponse.setDeviceInfoAvailable(false);
				authResponse.setDeviceInfoEnabled(true);
			}
			else
			{
				if (OptionManager.getOption(new Long(OptionConstants.DI_CHALLENGE_ENABLED), sessionVo.getLbId().longValue())
						.getIntValue() == 0)
				{
					authResponse.setDeviceInfoAvailable(true);
					authResponse.setDeviceInfoEnabled(false);

				}
				else
				{
					authResponse.setDeviceInfoAvailable(
						diChallengeUtils.isValidDeviceToken(httpRequest.getHeader(DEVICE_TOKENS), sessionVo));
					authResponse.setDeviceInfoEnabled(true);
				}
			}

		}


		authResponse.setTimeZone(new GregorianCalendar().getTimeZone().getID());

		resp.setData(authResponse);
		resp.setResponseOK();
		return resp;
	}


	@ApiOperation(value = "Get Session Time Remaining", notes = "Fetches the session time remaining to expire")
	@RequestMapping(value = "/session/getSessionTimeRemaining", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	@AllowEmulation
	@AllowedOnly(anyBankPerson = true, anyCustomerUser = true)
	public StandardResponse<SessionTimeResponse> getSessionTimeRemaining() throws BadSession, RemoteException
	{
		final SessionTimeResponse sessionResp = new SessionTimeResponse();
		final StandardResponse<SessionTimeResponse> resp = new StandardResponse<SessionTimeResponse>();
		sessionResp.setSessionTimeRemaining(sessionService.getSessionTimeRemaining(session.getSessionId()));
		sessionResp.setInactivityWarningLeadTime(session.getSessionVo().getInactivityWarningLeadTime());
		resp.setData(sessionResp);
		resp.setResponseOK();
		return resp;
	}

	@ApiOperation(value = "Extend session time", notes = "Extend session time and audit log the request")
	@RequestMapping(value = "/session/extend", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	@AllowedOnly(anyCustomerUser = true, anyBankPerson = true)
	@AllowEmulation
	public BasicResponse extend() throws BadSession, RemoteException, SQLException
	{
		final BasicResponse resp = new BasicResponse();
		magnetSessionDAO.updateSession(session.getSessionId());
		sessionService.getAuditSessionTimeExtension();

		resp.setResponseOK("User SessionTime extended successfully",
				"User SessionTime extended and audited for further tracking");
		return resp;
	}

	@ApiOperation(value = "Extend session time", notes = "Auto extend based on UI request")
	@RequestMapping(value = "/session/refresh", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	@AllowedOnly(anyCustomerUser = true, anyBankPerson = true)
	@AllowEmulation
	public BasicResponse refresh() throws BadSession, RemoteException, SQLException
	{
		final BasicResponse resp = new BasicResponse();
		magnetSessionDAO.updateSession(session.getSessionId());
		resp.setResponseOK("User Session refreshed successfully",
				"User SessionTime extended successfully");
		return resp;
	}


	private void makeFraudMapCall(final AuthenticationResponse authResponse, final HttpServletRequest httpRequest, SessionVO sessionVO)
	{
		if (authResponse.isChangePassword())
		{
			fraudCheckRequestUtils.populateAuthAndSendLoginEventIfFCEnabled(LogonUtils.LogonStatus.OTHER, "Success",
				ChallengeUtils.ChallengeReason.USER_CAUSED_RESET, sessionVO, authResponse.isFirstLogin(),
				authResponse.isMfaEnabled());
		}
		else
		{
			fraudCheckRequestUtils.populateAuthAndSendLoginEventIfFCEnabled(LogonUtils.LogonStatus.SUCCESSFUL, "Success",
				ChallengeUtils.ChallengeReason.USER_ACCESS_RESTRICTED, sessionVO, authResponse.isFirstLogin(),
				authResponse.isMfaEnabled());
		}
	}

}
