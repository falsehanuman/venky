package com.bottomline.cbe.authentication.domain.request;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.bottomline.cbe.servicescore.validation.constratints.NotBlank;
import com.fasterxml.jackson.annotation.JsonProperty;

public class PasswordResetRequest implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonProperty("oldPassword")
	@NotBlank(message = "PASSWORD_MISSING")
	private String oldPassword;
	
	@JsonProperty("newPassword")
	@NotBlank(message = "PASSWORD_MISSING")
	private String newPassword;

	
	public String getOldPassword() {
		return oldPassword;
	}

	public void setOldPassword(String oldPassword) {
		this.oldPassword = oldPassword;
	}

	public String getNewPassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}
	
}
