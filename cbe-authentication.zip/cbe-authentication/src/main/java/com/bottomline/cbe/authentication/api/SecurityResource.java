package com.bottomline.cbe.authentication.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bottomline.cbe.authentication.domain.request.AuditTrusteerStatusRequest;
import com.bottomline.cbe.authentication.domain.response.TrusteerSysOptionsResponse;
import com.bottomline.cbe.authentication.service.SecurityService;
import com.bottomline.cbe.context.SessionAware;
import com.bottomline.cbe.document.JiraRef;
import com.bottomline.cbe.servicescore.annotation.AllowEmulation;
import com.bottomline.cbe.servicescore.domain.response.StandardResponse;
import com.magnetbanking.util.activity.Activity;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/security")
public class SecurityResource
{

	@Autowired
	SecurityService securityService;
	
	@Autowired
	SessionAware sessionAware;
	
	final private String subService ="Trusteer";
	
	@JiraRef(value = { "CB-31876" })
	@ApiOperation(value = "Fetches trusteer options for the lead bank", notes = "Fetches trusteer settings for the lead bank")
	@RequestMapping(value = "/getTrusteerSystemOptions", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	@AllowEmulation
	public StandardResponse<TrusteerSysOptionsResponse> getTrusteerSystemOptions()
	{
		final StandardResponse<TrusteerSysOptionsResponse> response = new StandardResponse<>();
		response.setData(securityService.getTrusteerSysOptions());
		response.setResponseOK();
		return response;
	}
	
	@JiraRef(value = { "CB-33183" })
	@ApiOperation(value = "Audit log on trusteer rapport status", notes = "Audit log on the trusteer run status when user log in")
	@RequestMapping(value = "/auditTrusteerRapportStatus", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	public StandardResponse auditTrusteerRapportStatus(@RequestBody final AuditTrusteerStatusRequest request)
	{
		final StandardResponse response = new StandardResponse();
		Activity.log(sessionAware.getSessionVo(), subService, request.getAuditMessage());
		response.setResponseOK();
		return response;
	}
}
