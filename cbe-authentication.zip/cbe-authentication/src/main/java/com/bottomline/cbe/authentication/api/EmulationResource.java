package com.bottomline.cbe.authentication.api;

import static com.magnetbanking.foundation.services.iface.Service.EMULATE;

import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bottomline.cbe.authentication.domain.request.EmulationReq;
import com.bottomline.cbe.authentication.domain.response.EmulationSession;
import com.bottomline.cbe.authentication.service.EmulationService;
import com.bottomline.cbe.document.JiraRef;
import com.bottomline.cbe.servicescore.annotation.AllowedOnly;
import com.bottomline.cbe.servicescore.annotation.AllowedServices;
import com.bottomline.cbe.servicescore.domain.response.StandardResponse;

import io.swagger.annotations.ApiOperation;

/**
 * 
 * @author ravi.pulluri
 *
 */
@RestController
@RequestMapping("/emulation")
public class EmulationResource
{

	@Autowired
	private EmulationService emulationService;

	@JiraRef(value = { "CB-25954" })
	@PostMapping(value = "/listCustomers", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "To retrieve list of customer map with customer code and name")
	@AllowedServices(value = { EMULATE }, apiService = EMULATE)
	@AllowedOnly(anyBankPerson = true)
	public StandardResponse<Map<String, String>> listCustomers()
	{
		final StandardResponse<Map<String, String>> response = new StandardResponse<>();
		response.setData(emulationService.listEmulatableCustomers());
		response.setResponseOK();
		return response;
	}

	@JiraRef(value = { "CB-25954" })
	@PostMapping(value = "/listUsers", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "To retrieve list of user map with code and name")
	@AllowedServices(value = { EMULATE }, apiService = EMULATE)
	@AllowedOnly(anyBankPerson = true)
	public StandardResponse<Map<String, String>> listUsers(@Valid @RequestBody final EmulationReq listUsersReq)
	{
		final StandardResponse<Map<String, String>> response = new StandardResponse<>();
		response.setData(emulationService.listEmulatableUsers(listUsersReq));
		response.setResponseOK();
		return response;
	}

	@JiraRef(value = { "CB-25954" })
	@PostMapping(value = "/startEmulation", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "To start customer emulation session")
	@AllowedServices(value = { EMULATE }, apiService = EMULATE)
	@AllowedOnly(anyBankPerson = true)
	public StandardResponse<EmulationSession> startEmulation(@Valid @RequestBody final EmulationReq startEmulationReq)
	{
		final StandardResponse<EmulationSession> response = new StandardResponse<>();
		final Optional<EmulationSession> emulationSession = emulationService.startEmulation(startEmulationReq);
		if (emulationSession.isPresent())
		{
			response.setData(emulationSession.get());
		}
		response.setResponseOK();
		return response;
	}

}
