package com.bottomline.cbe.authentication.service;

import com.bottomline.foundation.session.vo.SessionVO;
import com.magnetbanking.foundation.session.iface.BadSession;

public interface SessionService
{

	public void deactivateSession() throws BadSession;

	public boolean isValidSession(SessionVO session) throws BadSession;

	public Long getSessionTimeRemaining(String sid) throws BadSession;

	public void getAuditSessionTimeExtension() throws BadSession;
}
