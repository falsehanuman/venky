package com.bottomline.cbe.authentication.domain.response;

import com.bottomline.cbe.challengemanager.ChallengeResponse;
import com.bottomline.cbe.challengemanager.ChallengeTypes;
import com.fasterxml.jackson.annotation.JsonProperty;

public class LoginChallengeResponse extends ChallengeResponse
{

	//1. deviceInfoEnabled should always be true
	//2. (deviceInfoPassed is false and isFirstLogin is true) or deviceInfoAvailable is false
	//if both of the above conditions are true, then display the checkbox to register device
	//	private boolean isLoginFromUnregisteredDevice;

	@JsonProperty("isFirstLogin")
	private boolean firstLogin;

	@JsonProperty("deviceInfoAvailable")
	private boolean deviceInfoAvailable;

	@JsonProperty("deviceInfoEnabled")
	private boolean deviceInfoEnabled;

	@JsonProperty("challengeType")
	private ChallengeTypes challengeType;

	public LoginChallengeResponse(ChallengeResponse source, AuthenticationResponse authenticationResponse)
	{
		setChalleangeable(source.isChalleangeable());
		setDefaultContactType(source.getDefaultContactType());
		setEmail(source.getEmail());
		setPhoneNumber(source.getPhoneNumber());
		setSessionId(source.getSessionId());
		setFirstLogin(authenticationResponse.isFirstLogin());
		setDeviceInfoAvailable(authenticationResponse.isDeviceInfoAvailable());
		setDeviceInfoEnabled(authenticationResponse.isDeviceInfoEnabled());
		setChallengeType(source.getChallengeType());
		setVoiceEnabled(source.isVoiceEnabled());
		setVoice(source.getVoice());
	}

	public boolean isFirstLogin()
	{
		return firstLogin;
	}

	public void setFirstLogin(boolean firstLogin)
	{
		this.firstLogin = firstLogin;
	}

	public boolean isDeviceInfoAvailable()
	{
		return deviceInfoAvailable;
	}

	public void setDeviceInfoAvailable(boolean deviceInfoAvailable)
	{
		this.deviceInfoAvailable = deviceInfoAvailable;
	}

	public boolean isDeviceInfoEnabled()
	{
		return deviceInfoEnabled;
	}

	public void setDeviceInfoEnabled(boolean deviceInfoEnabled)
	{
		this.deviceInfoEnabled = deviceInfoEnabled;
	}

	@Override
	public ChallengeTypes getChallengeType()
	{
		return challengeType;
	}

	@Override
	public void setChallengeType(ChallengeTypes challengeType)
	{
		this.challengeType = challengeType;
	}

}
